#include "server.h"
#include <QMessageBox>
Server::Server(QObject *parent):QTcpServer(parent)
{

}
