#ifndef SERVERUI_H
#define SERVERUI_H

#include <QWidget>
#include <QMouseEvent>
#include <QPushButton>
#include <QPoint>
#include <QtNetwork>
#include "server.h"
#include "property.h"
#include "data.h"
#include "Controller/OnlineCntroller.h"




QT_BEGIN_NAMESPACE
namespace Ui { class ServerUi; }
QT_END_NAMESPACE


class Server;

class ServerUi : public QWidget
{
    Q_OBJECT

public:
    ServerUi(QWidget *parent = nullptr);
    quint16 getPort();
    bool sendTo(QString & message,QTcpSocket * sender);
    void sendMessage(const QVariant & value, QTcpSocket * sender);
    void setClientProperties(const QVariant & properties, QTcpSocket * sender);
    QList<QTcpSocket *>getListOfClient() { return listeClients; }
    QPushButton * getOnlineButton();


    ~ServerUi();

private slots:
    void nouvelleConnexion();
    void deconnexion();
    void donneesRecues();
    void Online_Clicked();
    void OnRunningClicked();
    void onStopClicked();
    void setListeOfClient();
    void minimizeUi();
    void OnlineIsClosed();

protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent *event);

private:
    Ui::ServerUi * ui;
    Server * m_serveur;
    quint16 tailleMsg;
    QVariant container;
    Properties properties;
    QList<QTcpSocket *> listeClients;
    OnlineCntroller * onlineUi;
    bool mouseOff;
    bool isOnlineShow;


};
#endif // SERVERUI_H
