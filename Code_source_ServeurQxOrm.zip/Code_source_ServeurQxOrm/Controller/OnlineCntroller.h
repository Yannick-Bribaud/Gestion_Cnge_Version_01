#ifndef ONLINECNTROLLER_H
#define ONLINECNTROLLER_H

#include <QObject>
#include "UserOnline.h"
#include <QTcpSocket>
#include "property.h"
#include "data.h"

class OnlineCntroller :public QObject
{
    Q_OBJECT

public:
    OnlineCntroller(QObject * parent);
    void setListClient(QList<QTcpSocket *>liste);
    void run();


signals:
    void getListOfClients();
    void OnlineUiClosed();

private slots:
    void actualise();
    void minimized();
    void closeOnlineUi();

private:
    UserOnline * onlineUi;
    QList<QTcpSocket *>listeClients;
    QTcpSocket * client;
    Properties client_Props;
    QVariant property_client;


};

#endif // ONLINECNTROLLER_H
