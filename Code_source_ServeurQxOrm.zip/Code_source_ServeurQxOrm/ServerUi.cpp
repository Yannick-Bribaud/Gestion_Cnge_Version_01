#include "ServerUi.h"
#include "ui_serverui.h"
#include <QMessageBox>
#include <QDataStream>

ServerUi::ServerUi(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ServerUi)
{
        ui->setupUi(this);

        this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
        this->setAttribute(Qt::WA_TranslucentBackground);
    m_serveur=new Server(this); isOnlineShow=false;
    this->tailleMsg=0; mouseOff=false;

    ui->Running_Button->setIcon(QIcon(":/icon/play_96px.png"));
    ui->StopConnexion_Button->setIcon(QIcon(":/icon/stop_96px.png"));
    ui->StopServer_Button->setIcon(QIcon(":/icon/shutdown_96px.png"));
    ui->Close_Button->setIcon(QIcon(":/icon/close_window48_48px.png"));
    ui->minimizeUi_Button->setIcon(QIcon(":/icon/minimize_window_48px.png"));

    qRegisterMetaTypeStreamOperators<Properties>("Properties");
    qRegisterMetaTypeStreamOperators<Data>("Data");

    connect(ui->Close_Button, SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(ui->Running_Button, SIGNAL(clicked()), this, SLOT(OnRunningClicked()));
    connect(ui->StopConnexion_Button, SIGNAL(clicked()), this, SLOT(onStopClicked()));
    connect(ui->StopServer_Button, SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(m_serveur,SIGNAL(newConnection()), SLOT(nouvelleConnexion()));
    connect(ui->Online_Button,SIGNAL(clicked()),this,SLOT(Online_Clicked()));
    connect(ui->minimizeUi_Button,SIGNAL(clicked()),this,SLOT(minimizeUi()));

}

quint16 ServerUi::getPort(){
    return ui->Port->value();
}


bool ServerUi::sendTo(QString & message,QTcpSocket * sender)
{
    //Statique sending

    QByteArray paquet; QVariant Sendrproperty;
    Properties propSender;
    Properties propsReceiver;
    QTcpSocket * client; QVariant Reciverproperty;
    QDataStream out(&paquet,QIODevice::WriteOnly);
    out << (quint16)0;
    out << message;
    out.device()->seek(0);
    out << (quint16)(paquet.size() - sizeof(quint16));

    Sendrproperty=sender->property("Properties");
    propSender = Sendrproperty.value<Properties>();

     for(int i=0; i<listeClients.size(); i++){
            client=listeClients[i];

         Reciverproperty=client->property("Properties");
         propsReceiver=Reciverproperty.value<Properties>();

         if(propSender.ReceiverName==propsReceiver.clientName){
             sender->write(paquet);
             client->write(paquet);
             break;
         }
     }       return true;
}


void ServerUi::sendMessage(const QVariant &value, QTcpSocket *sender)
{
    //dynamique sending

    QVariant property; Properties props;
    Data data;
    data=value.value<Data>();
    QByteArray paquet;  QTcpSocket * client;
    QDataStream out(&paquet, QIODevice::WriteOnly);

    out << quint16(0);
    out << data.message;
    out.device()->seek(0);
    out << (quint16)(paquet.size() - sizeof (quint16));

    for(int i=0; i<listeClients.size(); i++){
           client=listeClients[i];

        property=client->property("Properties");
        props=property.value<Properties>();

        if(data.receiver==props.clientName){
            sender->write(paquet);
            client->write(paquet);
            break;
        }
    }
}

void ServerUi::setClientProperties(const QVariant & properties, QTcpSocket * sender)
{
    const char * name="Properties";

    for(int i=0; i<listeClients.size(); i++){
      if(listeClients[i]->socketDescriptor()==sender->socketDescriptor()){
            listeClients[i]->setProperty(name,properties);
      }
    }
}

QPushButton *ServerUi::getOnlineButton(){
    return ui->Online_Button;
}


ServerUi::~ServerUi()
{
    delete ui;
}

void ServerUi::nouvelleConnexion(){

     QTcpSocket * newClient = m_serveur->nextPendingConnection();
     properties = newClient->property("Properties").value<Properties>();
     listeClients << newClient;

      connect(newClient, SIGNAL(readyRead()),this, SLOT(donneesRecues()));
      connect(newClient, SIGNAL(disconnected()), SLOT(deconnexion()));
}

void ServerUi::deconnexion(){

    QTcpSocket * socket = qobject_cast<QTcpSocket *>(sender());
     if(socket==0)
         return;

    listeClients.removeOne(socket);
    socket->deleteLater();
}

void ServerUi::donneesRecues(){

    quint8 checkTypeData;
    QTcpSocket * socket = qobject_cast<QTcpSocket *>(sender());

    if(socket==0){
        return;
    }
    QDataStream in(socket);

    if(tailleMsg==0){
        if(socket->bytesAvailable() < (int)sizeof(quint16))
            return;
        in >> tailleMsg;
    }


    if(socket->bytesAvailable() < tailleMsg) return;
    in >> checkTypeData;

    if(checkTypeData=='P'){
        in >> container;
        setClientProperties(container,socket);
    }
    else{
        in >> container;
        sendMessage(container,socket); }

    tailleMsg=0;
}

void ServerUi::mousePressEvent(QMouseEvent *event)
{
   if(event->button()==Qt::LeftButton) {
       mouseOff=true;
    }
}

void ServerUi::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->Close){
        mouseOff=false;
    }
}

void ServerUi::mouseMoveEvent(QMouseEvent *event){
    mousePoint=event->globalPos();
    move(mousePoint);
}

void ServerUi::Online_Clicked(){
    if(!isOnlineShow){
      onlineUi = new OnlineCntroller(this);
      onlineUi->run();
      isOnlineShow=true;
    }

}

void ServerUi::OnRunningClicked()
{
    if(!m_serveur->listen(QHostAddress::Any,getPort())){
        QMessageBox::critical(this,"Error",m_serveur->errorString());
    }
    else{
        QMessageBox::information(this,"Serveur","Server is Running");
       ui->Running_Button->setEnabled(false);
    }
}

void ServerUi::onStopClicked(){
   if(m_serveur->isListening()){
        m_serveur->close();
        ui->Running_Button->setEnabled(true);
    QMessageBox::information(this,"Serveur","Server Stopped listenning");
   }
}

void ServerUi::setListeOfClient(){
    onlineUi->setListClient(listeClients);
}

void ServerUi::minimizeUi(){
    this->showMinimized();
}

void ServerUi::OnlineIsClosed(){
    isOnlineShow=false;
}




