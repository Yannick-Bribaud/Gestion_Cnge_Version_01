#include "data.h"

Data * getNewData()
{
  Data * data = new Data();
  return data;
}
