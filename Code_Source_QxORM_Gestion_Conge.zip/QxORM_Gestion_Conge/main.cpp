﻿#include "Precompilation/precompilation.h"
#include <QApplication>

#include "Qx_Connect_db/basedonnees.h"
#include "Entites/conges.h"
#include "Qx_Connect_db/qxdbconnect.h"
#include <QxOrm_Impl.h>
#include "Entites/employe.h"
#include "Entites/genre.h"
#include "Entites/status.h"
#include "Entites/manager.h"
#include "Entites/directeur_rh.h"
#include "Entites/administrateur.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesemploye.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesmanager.h"
#include "Prototypes_Metier/PersistanceModele/congesforemploye.h"
#include "Interface/QxTemplateDao/QxDaoTemplate.h"
#include "Implementation/IDaoImpl/idaoimpl.h"
#include "Gui/UILogin.h"
#include "Gui/SignIn.h"
#include "Gui/box.h"
#include "Gui/adminUI.h"
#include "Gui/AddUserUi.h"
#include <QPropertyAnimation>
#include "Gui/ProfileUI.h"
#include "Gui/ManagementUser.h"
#include "Controller/AdminCntrller.h"
#include "Controller/addUserContrller.h"
#include "Gui/setConges.h"
#include "Controller/setCngeCntrller.h"
#include "Gui/ManagementCnges.h"
#include "Controller/MngmntCngesCntrller.h"
#include "Gui/ServerUi.h"
#include "Controller/ServerCntroller.h"


int main(int argc, char *argv[])
{


    QApplication a(argc, argv);


    /*QFile styleSheetFile("C:/Qt/QThemes/Combinear.qss");
    styleSheetFile.open(QFile::ReadOnly);
    QString StyleSheet=QLatin1String(styleSheetFile.readAll());
    a.setStyleSheet(StyleSheet);*/


    try {

        QDate date(2021,04,13);
        QDate dateX(2013,05,14);
        QDate dateq(2020,10,2);
        QDate dateqx(2021,06,7);
       // quint8 duree=17;

        /*
        QxdbConnect * db = QxdbConnect::getInstance();
        bool rs=db->isConnected();

        qDebug() <<"Connected "<<rs;
*/
         modelCongesManagers_ptr mng;
         modelCongesManagers_ptr mng_1;


         modelEmployeConge_ptr emp_1;
         modelEmployeConge_ptr emp_2;
         modelEmployeConge_ptr emp_3;
         modelEmployeConge_ptr emp_4;
         modelEmployeConge_ptr empTest;
         empTest.reset(new ModelCongesEmploye());
        long id=64;


        mng.reset(new ModelCongesManager("ManagerUPdate","Brahim","DIAZ",Genre::EnumGenre::Homme,"@gmail","7477575"));
        mng_1.reset(new ModelCongesManager("ManagerNewsfd","IBBrahim","fQS",Genre::EnumGenre::Homme,"@gmail","7477575"));
          mng_1->setId(id);
        //mng.reset(new ModelCongesManager("ManagerBKMP","Brahim","DIAZ",Genre::EnumGenre::Homme,"@gmail","7477575",mng->getlist_of_ModelCongesEmploye()));


          list_of_modelManagers_ptr luste;
          mng->setId(id);
          luste.push_back(1,mng);
        emp_1.reset(new ModelCongesEmploye("FYHTT","JUL","pASq",Genre::EnumGenre::Homme,"@gmail.com","335543",mng_1));
        emp_2.reset(new ModelCongesEmploye("BCVC","LUC","HYTR",Genre::EnumGenre::Homme,"@gmail.com","867588",mng_1));
        emp_3.reset(new ModelCongesEmploye("nnvbbv","hhffL","pASq",Genre::EnumGenre::Homme,"@gmail.com","335543",mng));
        emp_4.reset(new ModelCongesEmploye("QZER","gbvbvb","bhhh",Genre::EnumGenre::Femme,"@gmail.com","335543",mng));


       // QSqlError daoError = qx::dao::save_with_relation("list_of_ModelCongesEmploye",mng);

        //QSqlError daoError = qx::dao::insert_with_all_relation(mng);

        //mng.reset(new ModelCongesManager("ManagerBKMP","Brahim","DIAZ",Genre::EnumGenre::Homme,"@gmail","7477575",mng->getlist_of_ModelCongesEmploye()));
        //list_of_modelManagers mnglist;
      //mnglist.push_back(1,mng);
       // QSqlError daoError;// = qx::dao::insert_with_all_relation(mnglist);

        /*
         * operation sur les conges
        CongesForEmploye_ptr conges; CongesForEmploye_ptr Cng;
        emp_1->setId(50);
        conges.reset(new CongesForEmploye(dateX,duree,dateq,emp_1));

        //QSqlError daoError = qx::dao::save_with_all_relation(conges);

         QSqlError daoError = qx::dao::fetch_by_id_with_relation("list_of_CongesEmploye",emp_1);

         qDebug() << "Congés";
         for(long l=0; l<emp_1->getlist_of_CongesEmploye().count();++l)
         {
           Cng= emp_1->getlist_of_CongesEmploye().getByIndex(l);
           qDebug() << Cng->getDuree();
           qDebug() << Cng->getFinConge();

         }*/




        // mng.reset(new ModelCongesManager("WXMC","Ludos","Bribaud",Genre::EnumGenre::Homme,"ludo@gmail.com","7865552",listeEmpl));
        //modelEmployeConge_ptr emp; liste_modelCngeEmploye listte;
       // emp.reset(new ModelCongesEmploye("GFD","PATRICKQS","BriDSbaud",Genre::EnumGenre::Homme,"Patt@gmail.com","98686852",mng));
       // emp.reset(new Administrateur("yannick","Bribaud",Genre::EnumGenre::Homme,date,"Dakar","884774","MKOO14","Devel",Status::EnumStatus::Manager,"login","passer","brib@gmail.com"));
        //liste_modelCngeEmploye_ptr liste;
       // liste.push_back(1,*emp_1);
       // liste.push_back(2,emp_2);
        //listte.push_back(*emp_2);
        /*liste.push_back(3,*emp_3);
        liste.push_back(4,*emp_4);
        liste.push_back(5,*emp_1);*/




        //QSqlError daoError = qx::dao::delete_by_id(mng);




       /* StringList lstColumns = QStringList() << "date_creation";
           list_blog lst_blog_with_only_date_creation;
           daoError = qx::dao::fetch_all(lst_blog_with_only_date_creation, NULL, lstColumns);*/

        //list_of_modelManagers_ptr listManger;

     //QStringList listMng = QStringList() <<"id";
   // QSqlError daoError = qx::dao::fetch_all(listManger,NULL,listMng);





        //bool rst=QxDaoTemplate::PersisteObject::PersistWithSave(luste);
        //qDebug()<<" Bool "<<rst;


       // Managr_ptr mngr; mngr.reset(new Managers("yannick","Briba",Genre::EnumGenre::Homme,date,"Dakar","884774","MKOO14","Devel",Status::EnumStatus::Manager,"login","passer","brib@gmail.com"));
        /*qDebug()<<model->getNom();
        qDebug()<<emp->getPrenom();
        qDebug()<<emp->getGenre();
        qDebug()<<emp->getStatus();
        qDebug()<<emp->getDateNaissance();
        qDebug()<<emp->getMatricule();
        qDebug()<<emp->getPassword();
        qDebug()<<emp->getProfession();
        qDebug()<<emp->getId();
        */

        //listEmp.push_back(100,*model);
       // QSqlError daoError = qx::dao::insert_with_all_relation(listEmp);

          // liste_modelCngeEmploye listAllEmpl;

      //  qx_query testStoredProcBis("SELECT * FROM t_modelCongesEmploye");
       // listAllEmpl.clear();
     //  QSqlError  daoError = qx::dao::execute_query(testStoredProcBis, listAllEmpl);

      /* foreach(auto Emp, listAllEmpl ){
           qDebug() << Emp.getId();
           qDebug() << Emp.getMatricule();
       }*/


        std::shared_ptr<QList<ModelCongesEmploye>>listE;

        //QSqlError daoError = qx::dao::fetch_all(listAllEmpl);
         //QList<ModelCongesManager>ll; ModelCongesManager model;

      /*   modelCongesManagers_ptr modell;
         modell.reset(new ModelCongesManager());
         modell->setId(id);

         long ids=64;
         mng->setId(ids);
         mng->getlist_of_ModelCongesEmploye().clear();*/

         //long it=1;
       //  QSqlError daoError = qx::dao::fetch_by_id_with_relation("list_of_ModelCongesEmploye",mng);

/*
        for(long l=0; l<mng->getlist_of_ModelCongesEmploye().count();++l)
        {
          empTest= mng->getlist_of_ModelCongesEmploye().getByIndex(l);
          qDebug() << empTest->getNom();
          qDebug() << empTest->getDateNaissance();

        }

        if(typeid (mng).name() == typeid (empTest).name())
        {
            qDebug() << typeid (mng).name();
        }



        qDebug()<<"-----------------------------------------------------------------------";

        //query = qx_query(); query.freeText("WHERE author.sex=:sex AND author.author_id=:author_id", QVariantList() << author::female << "author_id_2");

        professionel_ptr pro_ptr; employe_ptr empla;
        empla.reset(new Employe(date,dateq,4,"Messi","Lionel",Genre::EnumGenre::Homme,dateX,"Argentine","7783234","Foot454","Footballeur",Status::EnumStatus::Manager,"login","Password","@gmail"));
        admin_ptr admiptr; Managr_ptr manager;
       admiptr.reset(new Administrateur("Messi","Lionel",Genre::EnumGenre::Homme,dateX,"Argentine","7783234","Foot454","Footballeur",Status::EnumStatus::Manager,"login","Password","@gmail"));
        //admiptr.reset(new Administrateur());

       liste_professionnel_ptr PTR;

        IDaoImpl * daoImp= new IDaoImpl();
        pro_ptr=daoImp->getProfessionalInfoFromEmploye(empla);

        professionel_ptr check;
        check=daoImp->checkIdentifier("logins","password");
        qDebug() <<"check";
        qDebug()<<check->getStatus();


*/


       // QxDaoTemplate::PersisteObject::SaveObject(pro_ptr);

      /*  DaoImplement_ptr daoImpl;
        daoImpl.reset(new IDaoImpl());
        pro_ptr=daoImpl->getProfessionalInfoFromManager(manager);*/

       /* qDebug()<<pro_ptr->getNom();
        qDebug()<<pro_ptr->getEmail();
        qDebug()<<pro_ptr->getGenre();
        qDebug()<<pro_ptr->getStatus();
        qDebug()<<pro_ptr->getPassword();*/



           // qDebug() <<"By Id"<< modell->getNom();

      //  ll=QxDaoTemplate::getDataTable::SelectAllDataOfTable(model);

      //  foreach(auto Emp, ll ){
                   //qDebug() << Emp.getId();
                  // qDebug() << Emp.getMatricule();
       // }

     // if(daoError.isValid()){ qDebug() << "Error";}
        //qx_query query("S")


       // dmnde_ptr demand; emp_1->setId(58);
       // QTime time=QTime::currentTime();

        //demand.reset(new Demande(id,dateqx,duree,dateq,dateq,time,emp_1));
        /*QSqlError daoError = qx::dao::save_with_all_relation(demand);*/

    /*
        ValidationConges_ptr valider;
        demand->setId(3);
        id=34;
        valider.reset(new ValidationConges(dateqx,time,"Valide",id));
        QSqlError daoError = qx::dao::insert_with_all_relation(valider);*/


    }  catch (dbError e) {
        qDebug()<<"Code Error"<<e.getCodErreur();
        qDebug()<<"KGKL"<<e.getMessage();

      }catch (daoException e) {
        qDebug()<<"daoEx"<<e.getMessage();
    }

    BaseDeDonnee::detruireInstance();


QPropertyAnimation * anim;

    UILogin ui;
    adminUI adm;
    ProfileUI ProUi;
    AddUserUi addUser;
    ManagementUser mngUser;
    SignIn s_Ui;
    AdminCntrller * cntrlAdmin= new AdminCntrller();
    cntrlAdmin->run();

    //ServerCntroller * cntrServer=new ServerCntroller();
   // cntrServer->run();

    //ServerUi Server;
   // Server.show();

    //MngmntCngesCntrller * cngesUi=new MngmntCngesCntrller();
    //cngesUi->run();

   // ManagementCnges cnge;
    //cnge.show();

    setConges uiCnges;

    //Box *box=new Box("Sign In Error",1,"Authentification Echoué,veuillez reessayer!",NULL);
   // ui.show();
  // Ui.show();



   anim = new QPropertyAnimation(&ui, "geometry");
   anim->setDuration(900);
   anim->setEasingCurve(QEasingCurve::InOutSine);
   anim->setStartValue(QRectF(1800,0,ui.width(),ui.height()));
   anim->setEndValue(QRectF(800,200,ui.width(),ui.height()));
   anim->start();

    return a.exec();
}
