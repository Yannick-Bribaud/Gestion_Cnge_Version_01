#include "Precompilation/precompilation.h"
#include "demande.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Demande)

namespace qx {

template <> void register_class(QxClass<Demande> & Dmd){
        Dmd.setName("t_demandes");
        Dmd.id(&Demande::dmd_id,"idDmnd");
        Dmd.data(&Demande::dmd_date_soumission,"dateSoumission");
        Dmd.data(&Demande::dmd_heure_soumission,"heureSoumission");
        Dmd.data(&Demande::dbutCnge,"dbutCnge");
        Dmd.data(&Demande::dmd_dureeConge,"dureeConge");
        Dmd.data(&Demande::dmd_finCnge,"finConge");

        Dmd.relationManyToOne(&Demande::m_modelCongesEmploye,"idEmploye");


    }

}
