#ifndef MANAGER_H
#define MANAGER_H
#include "personne.h"
#include "professionnel.h"
#include "Utilitaires/HandlerEnumeration.h"

class _QX_DLL_EXPORT_GESTION_CONGES Managers : public Professionnel
{
    QX_REGISTER_FRIEND_CLASS(Managers)

public:
     void methodeAbstraite() override {};

    Managers(){};
    Managers(const QString & nom, const QString & prenom, Genre::EnumGenre genre, QDate dateN, const QString & adresse, const QString & telephone,
             const QString & matricule, const QString & profession, Status::EnumStatus status, const QString & login, const QString & password, const QString & email)
            :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){};

    virtual ~Managers(){};

private:

};

QX_REGISTER_HPP_ENTITY(Managers,Personne,0)

typedef std::shared_ptr<Managers> Managr_ptr;
typedef QList<Managers>liste_managr;
typedef qx::QxCollection<long, Managr_ptr> liste_managr_ptr;

#endif // MANAGER_H
