#ifndef ADMINISTRATEUR_H
#define ADMINISTRATEUR_H

#include "personne.h"
#include "professionnel.h"

class _QX_DLL_EXPORT_GESTION_CONGES Administrateur : public Professionnel
{
    QX_REGISTER_FRIEND_CLASS(Administrateur)

public:

    void methodeAbstraite() override {};
    Administrateur(){};
    Administrateur(QString nom, QString prenom, Genre::EnumGenre genre, QDate dateN, QString adresse, QString telephone,
                   QString matricule,QString profession, Status::EnumStatus status, QString login, QString password,QString email)
                   :Professionnel(nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){;}
    virtual ~Administrateur() {};

private:


};


QX_REGISTER_HPP_ENTITY(Administrateur,Personne,0);

typedef std::shared_ptr<Administrateur> admin_ptr;
typedef QList<Administrateur> liste_admin;
typedef qx::QxCollection<long, admin_ptr> liste_admin_ptr;
#endif // ADMINISTRATEUR_H
