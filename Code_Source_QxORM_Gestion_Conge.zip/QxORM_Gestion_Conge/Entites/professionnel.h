#ifndef PROFESSIONNEL_H
#define PROFESSIONNEL_H

#include "personne.h"
#include "Entites/status.h"
#include "Utilitaires/HandlerEnumeration.h"

class _QX_DLL_EXPORT_GESTION_CONGES Professionnel : public Personne
{
    QX_REGISTER_FRIEND_CLASS(Professionnel)

public:
    //Virtuelles methodes
    void methodeAbstraite() override{};

    Professionnel() {};
    Professionnel(QString status):pro_status(status){};
    Professionnel(QString nom, QString prenom, Genre::EnumGenre genre, QDate dateN, QString adresse, QString telephone,
                  QString matricule,QString profession, Status::EnumStatus status, QString login, QString password,QString email)
                  :Personne(nom,prenom,genre,dateN,adresse,telephone),pro_matricule(matricule),pro_profession(profession),
                   pro_login(login),pro_password(password),pro_email(email){ setStatus(status); }

    virtual ~Professionnel(){};

    //getters
    QString getMatricule() const { return pro_matricule; }
    QString getProfession() const {return pro_profession; }
    QString getStatus() const {return  pro_status;}
    Status::EnumStatus getStatusEnum();
    QString getLoging() const {return pro_status;}
    QString getPassword() const {return pro_password;}
    QString getEmail() const {return  pro_email; }

    //setters
    void setMatricule(const QString & matricule) {pro_matricule = matricule;}
    void setProfession(const QString & profession) {pro_profession = profession;}
    void setStatus(const Status::EnumStatus & status);
    void setLogin(const QString & login) { pro_status = login;}
    void setPassword(const QString & password) {pro_password = password;}
    void setEmail(const QString & email) {pro_email = email;}

protected:

    QString pro_matricule;
    QString pro_profession;
    QString pro_status;
    QString pro_login;
    QString pro_password;
    QString pro_email;

private:



};

QX_REGISTER_HPP_ENTITY(Professionnel,Personne,0);

typedef std::shared_ptr<Professionnel> professionel_ptr;
typedef QList<Professionnel> liste_professionnel;
typedef qx::QxCollection<long, professionel_ptr> liste_professionnel_ptr;
#endif // PROFESSIONNEL_H
