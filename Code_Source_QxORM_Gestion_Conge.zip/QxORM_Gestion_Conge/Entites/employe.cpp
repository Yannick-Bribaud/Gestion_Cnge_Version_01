#include "Precompilation/precompilation.h"
#include "employe.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Employe)

namespace qx {

    template<> void register_class(QxClass<Employe> & Emp){

        Emp.setName("t_employe");


        Emp.data(&Employe::e_debutPeriode,"debutPeriode");
        Emp.data(&Employe::e_finPeriode,"finPeriode");
        Emp.data(&Employe::e_soldeConge, "soldeConge");
        Emp.data(&Employe::pro_matricule,"matricule");
        Emp.data(&Employe::pro_profession,"profession");
        Emp.data(&Employe::pro_status, "status");
        Emp.data(&Employe::pro_login, "login");
        Emp.data(&Employe::pro_password, "password");
        Emp.data(&Employe::pro_email, "email");


    }
}

