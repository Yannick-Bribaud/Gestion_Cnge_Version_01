#include "Precompilation/precompilation.h"
#include "validation.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Validation)

namespace qx {

template <> void register_class(QxClass<Validation> & valide){


    valide.id(&Validation::id,"idVld");
    valide.data(&Validation::dateValidation,"dateValidation");
    valide.data(&Validation::heureValidation,"heureValidation");
    valide.data(&Validation::verdict,"verdict");

 }
}


