#ifndef STATUS_H
#define STATUS_H


class _QX_DLL_EXPORT_GESTION_CONGES Status : public QObject
{
    Q_OBJECT

public:

    enum class EnumStatus{
        Manager = 0,
        Employe = 1,
        Administration = 2,
        Directeur_Ressources_Humaines = 3
    };

    Q_ENUM(EnumStatus);

private:
    Status(){};
    virtual ~Status(){};
};

#endif // STATUS_H
