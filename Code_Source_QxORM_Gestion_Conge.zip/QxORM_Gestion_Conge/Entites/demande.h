#ifndef DEMANDE_H
#define DEMANDE_H
#include "Prototypes_Metier/PersistanceModele/modelcongesemploye.h"
#include "Prototypes_Metier/PersistanceModele/validationconges.h"

class ModelCongesEmploye;
class ValidationConges;

class _QX_DLL_EXPORT_GESTION_CONGES Demande
{
    QX_REGISTER_FRIEND_CLASS(Demande)

public:
      typedef std::shared_ptr<ModelCongesEmploye>modelCongeEmploye_ptr;

      Demande(){};
      Demande(QDate dbutCnge,qint8 dureeConge,QDate finCnge,const QDate & date_soumission, const QTime & heure_soumission, const modelCongeEmploye_ptr & employe)
              :dbutCnge(dbutCnge),dmd_dureeConge(dureeConge),dmd_finCnge(finCnge),dmd_date_soumission(date_soumission),dmd_heure_soumission(heure_soumission){ m_modelCongesEmploye = employe; };
      Demande(long id,QDate dbutCnge,qint8 dureeConge,QDate finCnge,const QDate & date_soumission, const QTime & heure_soumission, const modelCongeEmploye_ptr & employe):
                dmd_id(id),dbutCnge(dbutCnge),dmd_dureeConge(dureeConge),dmd_finCnge(finCnge),dmd_date_soumission(date_soumission),dmd_heure_soumission(heure_soumission){ m_modelCongesEmploye = employe; };
      Demande(long dmd_id, const QDate & dbutCnge, qint8 & dmd_dureeConge,const QDate & finCnge, const QDate & dmd_date_soumission,const QTime & dmd_heure_soumission, const modelCongeEmploye_ptr & employe):
              dmd_id(dmd_id),dbutCnge(dbutCnge),dmd_dureeConge(dmd_dureeConge),dmd_finCnge(finCnge),dmd_date_soumission(dmd_date_soumission),dmd_heure_soumission(dmd_heure_soumission){ m_modelCongesEmploye = employe; }
      virtual ~Demande(){};

      //setters
      void setId(long id){dmd_id=id;}
      void setDureeCng(quint8 duree){dmd_dureeConge=duree;}
      void setDateSoumission(const QDate & dateSoumission){ dmd_date_soumission=dateSoumission;}
      void setheureSoumission(const QTime & heureSoumission){ dmd_heure_soumission=heureSoumission;}
      void setDbutCng(const QDate & dbutCnge){ this->dbutCnge=dbutCnge; }
      void setFinCnge(const QDate & finCnge) { this->dmd_finCnge=finCnge; }

      //getters
      long getId() const { return dmd_id; }
      QDate getDbutCng() const { return dbutCnge;}
      quint8 getDureeCng() const { return dmd_dureeConge; }
      QDate getfinCnge() const {return dmd_finCnge;}
      QDate getDateSoumission() const { return dmd_date_soumission; }
      QTime getHeureSoumission() const {return dmd_heure_soumission; }

private:
    long  dmd_id;
    QDate dbutCnge;
    qint8 dmd_dureeConge;
    QDate dmd_finCnge;
    QDate dmd_date_soumission;
    QTime dmd_heure_soumission;

    modelCongeEmploye_ptr m_modelCongesEmploye;
};


QX_REGISTER_HPP_ENTITY(Demande,qx::trait::no_base_class_defined,0)
typedef std::shared_ptr<Demande>dmnde_ptr;
typedef qx::QxCollection<long, Demande>liste_dmande;
#endif // DEMANDE_H
