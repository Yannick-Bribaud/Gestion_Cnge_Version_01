#include "Precompilation/precompilation.h"
#include "administrateur.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Administrateur)

namespace qx {

  template <> void register_class(QxClass<Administrateur> &Admin){

        Admin.setName("t_administrateur");
        Admin.data(&Administrateur::pro_matricule, "matricule");
        Admin.data(&Administrateur::pro_profession,"profession");
        Admin.data(&Administrateur::pro_status,    "status");
        Admin.data(&Administrateur::pro_login,     "login");
        Admin.data(&Administrateur::pro_password,  "password");
        Admin.data(&Administrateur::pro_email,     "email");

    }
}
