#include "Precompilation/precompilation.h"
#include "conges.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Conges)

namespace qx {
    template <> void register_class(QxClass<Conges> & Cng){

    Cng.setName("t_conges");
    Cng.id(&Conges::c_id, "idCng");
    Cng.data(&Conges::c_debutConge, "dbutCnge");
    Cng.data(&Conges::c_duree, "dureeCnge");
    Cng.data(&Conges::c_finConge, "finCnge");


}

}
