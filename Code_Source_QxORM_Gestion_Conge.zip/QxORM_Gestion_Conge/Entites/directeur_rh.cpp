#include "Precompilation/precompilation.h"
#include "directeur_rh.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Directeur_RH)

namespace qx {
    template <>void register_class(QxClass<Directeur_RH> & DRH){
        DRH.setName("t_directeur_rh");

        DRH.data(&Directeur_RH::pro_matricule, "matricule");
        DRH.data(&Directeur_RH::pro_profession,"profession");
        DRH.data(&Directeur_RH::pro_status, "status");
        DRH.data(&Directeur_RH::pro_login, "login");
        DRH.data(&Directeur_RH::pro_password, "password");
        DRH.data(&Directeur_RH::pro_email, "email");

    }
}
