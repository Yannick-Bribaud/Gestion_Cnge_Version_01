#ifndef VALIDATION_H
#define VALIDATION_H


class _QX_DLL_EXPORT_GESTION_CONGES Validation
{
    QX_REGISTER_FRIEND_CLASS(Validation)

public:
        virtual void methodeAbstraite()=0;

        Validation(){};
        Validation(const QDate & dateV, const QTime & heureV, const QString & verdict):dateValidation(dateV),heureValidation(heureV),verdict(verdict){}
        Validation(long id,const QDate & dateV, const QTime & heureV, const QString & verdict):id(id), dateValidation(dateV),heureValidation(heureV),verdict(verdict){}
        virtual ~Validation(){};

        void setId(const long & idV) { id=idV ;}
        void setDateValidation(const QDate & dateV){ dateValidation = dateV; }
        void setHeureValidation(const QTime & heure) {heureValidation = heure; }
        void setVerdict(const QString & verdict) {this->verdict=verdict; }

        long  getId() const {return id;}
        QDate getDate() const {return dateValidation ;}
        QTime getTime() const {return heureValidation ;}
        QString getVerdict() const { return verdict ;}

protected:
    long id;
    QDate dateValidation;
    QTime heureValidation;
    QString verdict;

};


QX_REGISTER_ABSTRACT_CLASS(Validation)
QX_REGISTER_HPP_ENTITY(Validation,qx::trait::no_base_class_defined,0);

typedef std::shared_ptr<Validation>validation_ptr;
typedef qx::QxCollection<long, validation_ptr> liste_validation;
#endif // VALIDATION_H
