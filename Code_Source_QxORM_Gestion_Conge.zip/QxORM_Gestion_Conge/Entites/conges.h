#ifndef CONGES_H
#define CONGES_H


class _QX_DLL_EXPORT_GESTION_CONGES Conges
{
    QX_REGISTER_FRIEND_CLASS(Conges)

public:

    Conges(){};
    Conges(QDate debutConge, qint8 duree, QDate finConge):c_id(0),c_debutConge(debutConge),c_duree(duree),c_finConge(finConge){};
    virtual ~Conges(){};

    //methode abstraite
    virtual void methodeAbstraite()=0;

    //getters
    long getId() const { return  c_id; }
    QDate getDebutConge() const { return c_debutConge;}
    qint8 getDuree() const { return c_duree; }
    QDate getFinConge() const { return c_finConge; }

    //settters
    void setId(long identifiant) { c_id = identifiant; }
    void setDebutConge(const QDate & DebutConge) {c_debutConge = DebutConge;}
    void setDuree(const qint8 & dureeConge) {c_duree = dureeConge; }
    void setFinConge(const QDate & finConge) { c_finConge = finConge; }

protected:
    long  c_id;
    QDate c_debutConge;
    qint8 c_duree;
    QDate c_finConge;
};


QX_REGISTER_ABSTRACT_CLASS(Conges)
QX_REGISTER_HPP_ENTITY(Conges,qx::trait::no_base_class_defined,0)

typedef std::shared_ptr<Conges> conges_ptr;
typedef std::vector<conges_ptr>liste_conges;
#endif // CONGES_H
