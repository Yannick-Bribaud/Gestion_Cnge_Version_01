#include "Precompilation/precompilation.h"
#include "personne.h"
#include <QxOrm_Impl.h>
#include "Prototypes_Metier/PersistanceModele/modelcongesmanager.h"

QX_REGISTER_CPP_ENTITY(Personne)

  //enregistrer la classe dans le context de QXORM
namespace  qx {
template <> void register_class(QxClass<Personne> & P)
 {
      P.setName("t_personne");
      P.id(& Personne::p_id, "id" );
      P.data(& Personne::p_nom, "nom" );
      P.data(& Personne::p_prenom,"prenom" );
      P.data(& Personne::p_genre,  "genre" );
      P.data(& Personne::p_dateNaissance,"dateNaissance" );
      P.data(& Personne::p_adresse, "adresse" );
      P.data(& Personne::p_telephone, "telephone" );

 }
}

Genre::EnumGenre Personne::getGenreEnum(){
    QString strGenre = getGenre();
    Genre::EnumGenre genreEnum=HandlerEnums::fromString<Genre::EnumGenre>(strGenre);
    return genreEnum;
}

void Personne::setGenre(Genre::EnumGenre genre){
    QString text;
    text = HandlerEnums::convertToString(genre);
    p_genre=text;
}




