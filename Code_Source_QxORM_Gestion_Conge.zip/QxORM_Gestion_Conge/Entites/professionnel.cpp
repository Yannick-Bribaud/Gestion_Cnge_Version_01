#include "Precompilation/precompilation.h"
#include "professionnel.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(Professionnel)

  //enregistrer la classe dans le context de QXORM
namespace  qx {
template <> void register_class(QxClass<Professionnel> & Pro)
 {
      Pro.setName("t_professionnel");

      Pro.data(& Professionnel::pro_matricule, "matricule" );
      Pro.data(& Professionnel::pro_profession,"profession" );
      Pro.data(& Professionnel::pro_status,  "status" );
      Pro.data(& Professionnel::pro_login,  "login");
      Pro.data(& Professionnel::pro_password, "password" );
      Pro.data(& Professionnel::pro_email, "email" );


 }
}


Status::EnumStatus Professionnel::getStatusEnum(){
    QString strStatusEnum=getStatus();
    Status::EnumStatus StatusEnum = HandlerEnums::fromString<Status::EnumStatus>(strStatusEnum);
    return StatusEnum;
}

void Professionnel::setStatus(const Status::EnumStatus &status){
    QString text;
    text=HandlerEnums::convertToString(status);
    pro_status=text;
}
