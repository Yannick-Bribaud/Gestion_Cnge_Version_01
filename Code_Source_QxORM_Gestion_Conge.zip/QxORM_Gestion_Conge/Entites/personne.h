#ifndef PERSONNE_H
#define PERSONNE_H

#include "Entites/genre.h"
#include "Utilitaires/HandlerEnumeration.h"

class _QX_DLL_EXPORT_GESTION_CONGES Personne:public QObject
{
    QX_REGISTER_FRIEND_CLASS(Personne)

public:

    Personne(){};
    Personne(const QString & nom, const QString & prenom, Genre::EnumGenre genre, QDate dateN, const QString & adresse, const QString & telephone)
            :p_nom(nom),p_prenom(prenom),p_dateNaissance(dateN),p_adresse(adresse), p_telephone(telephone){ setGenre(genre); }
    virtual ~Personne() {};

    //methode virtuelle pure
    virtual void methodeAbstraite()=0;

    //getters
    long getId() const { return p_id; }
    QString getNom() const {return p_nom;}
    QString getPrenom() const {return p_prenom;}
    QString getGenre() const {return p_genre;}
    Genre::EnumGenre getGenreEnum();
    QDate   getDateNaissance() const {return p_dateNaissance;}
    QString getAdresse() const {return p_adresse;}
    QString getTelephone() const {return p_telephone;}

    // setters
    void setId(const long id) {p_id = id;}
    void setNom(const QString & nom) { p_nom= nom;}
    void setPrenom(const QString & prenom) { p_prenom = prenom;}
    void setGenre(Genre::EnumGenre genre);
    void setDateNaissance(const QDate & date) { p_dateNaissance = date;}
    void setAdresse(const QString & adresse) {p_adresse = adresse;}
    void setTelephone(const QString & telephone) {p_telephone = telephone; }

protected:

    long p_id;
    QString p_nom;
    QString p_prenom;
    QString p_genre;
    QDate   p_dateNaissance;
    QString p_adresse;
    QString p_telephone;

private:
    void isValid(qx::QxInvalidValue & InvalidValue);

};

QX_REGISTER_ABSTRACT_CLASS(Personne)
QX_REGISTER_HPP_ENTITY(Personne,qx::trait::no_base_class_defined,0);

//Optionnelle
typedef std::shared_ptr<Personne> persnne_ptr;
typedef qx::QxCollection<long, Personne> liste_personne;
typedef qx::QxCollection<long, persnne_ptr> liste_personne_ptr;

#endif // PERSONNE_H
