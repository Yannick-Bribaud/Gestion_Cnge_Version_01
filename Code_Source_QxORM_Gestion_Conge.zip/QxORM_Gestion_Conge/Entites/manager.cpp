#include "Precompilation/precompilation.h"
#include "manager.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(Managers)

namespace qx {
template <> void register_class(QxClass<Managers> &Mng){

    Mng.setName("t_managers");
    Mng.data(&Managers::pro_matricule,"matricule");
    Mng.data(&Managers::pro_profession,"profession");
    Mng.data(&Managers::pro_status,"status");
    Mng.data(&Managers::pro_login,"login");
    Mng.data(&Managers::pro_password,"password");
    Mng.data(&Managers::pro_email,"email");
}

}



