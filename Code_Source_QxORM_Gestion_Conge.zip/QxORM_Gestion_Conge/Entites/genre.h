#ifndef GENRE_H
#define GENRE_H

#include <QMetaEnum>
class _QX_DLL_EXPORT_GESTION_CONGES Genre : public QObject
{
    Q_OBJECT;
public:
     enum class EnumGenre{
         Homme = 0,
         Femme = 1,
         Inconnu = 2
    };

     Q_ENUM(EnumGenre);

private:
    Genre(){};
    virtual ~Genre(){};

};

#endif // GENRE_H
