#ifndef SERVICESPROFESSIONNELS_H
#define SERVICESPROFESSIONNELS_H
#include "Implementation/IDaoImpl/idaoimpl.h"
#include "Entites/professionnel.h"
#include "Exceptions/SqlExceptions/daoexception.h"
#include "Exceptions/ServicesExceptions/servicesexceptions.h"
#include "Exceptions/UserExceptions/userExceptions.h"

class ServicesProfessionnels
{
public:
    ServicesProfessionnels();
    professionel_ptr Authentification(const QString & login, const QString & password);

private:
    IDaoImpl * s_daoImpl;
    professionel_ptr user;

};

#endif // SERVICESPROFESSIONNELS_H
