#include "servicesprofessionnels.h"

ServicesProfessionnels::ServicesProfessionnels(){
    s_daoImpl = new IDaoImpl();
}

professionel_ptr ServicesProfessionnels::Authentification(const QString &login, const QString & password){
   try{

        if(login.isEmpty() || password.isEmpty()){

            throw userExceptions("veuillez remplir tous les champs svp!");
            return NULL;
        }
       return user = s_daoImpl->checkIdentifier(login,password);

    } catch(dbError ex)  {
       throw  ServicesExceptions(ex.getMessage());

    }catch (daoException e){
      throw  ServicesExceptions(e.getMessage());
    }

    return NULL;
}
