#include "ServerCntroller.h"

ServerCntroller::ServerCntroller(QObject *parent){
    serverUi=nullptr;
    connect(this,SIGNAL(closeServerSignal()),parent,SLOT(closeServer()));
}

void ServerCntroller::run(){
    if(!isServerUishow){
        serverUi = new ServerUi(this);
        serverUi->show();
        isServerUishow=true;
    }
}

void ServerCntroller::StartProcess(){
    serverUi->getQSystemTrayIcon()->showMessage(tr("Notification"),tr("Programme serveur Demarré..."),QIcon(":/img/Images/info_squared_96px.png"));
}

void ServerCntroller::execBtn(){
    if(serverUi->getProcess()->state()!=QProcess::Running){
       serverUi->getProcess()->setProgram("C:/CodeprogC++/QxORM_Gestion_Conge/Server/release/ServeurQxOrm.exe");
       serverUi->getProcess()->start();
    }
}

void ServerCntroller::CloseServerUi(){
    if(isServerUishow){
       serverUi->close();
       isServerUishow=false;
       emit closeServerSignal();
    }
}
