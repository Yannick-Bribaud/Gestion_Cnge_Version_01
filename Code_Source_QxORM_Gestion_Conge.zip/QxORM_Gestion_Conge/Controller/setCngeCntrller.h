#ifndef SETCNGECNTRLLER_H
#define SETCNGECNTRLLER_H
#include "Gui/setConges.h"
#include <QPropertyAnimation>
#include <QTimer>
#include "Exceptions/UserExceptions/userExceptions.h"
#include "Gui/box.h"

class setCngeCntrller : public QObject
{
    Q_OBJECT

public:
    setCngeCntrller();
    void run();
    QDate getBeginDate();
    quint8 getDuration();
    QDate getEndDate() ;

public slots:
    void CloseSetCngeUI();
    void setPeriodAndDuration();
    void ClickedOnBtnBox();


private:
  setConges * setCngesUi;
  QDate beginDate;
  quint8 duration;
  QDate EndDate;
  QPropertyAnimation * animation;
  QTimer *timer;
  Box * MessageBox;


};

#endif // SETCNGECNTRLLER_H
