#include "MngmntCngesCntrller.h"

MngmntCngesCntrller::MngmntCngesCntrller(QObject *parent){
    CngesUi=nullptr;
    connect(this,SIGNAL(CngesUiclosed()),parent,SLOT(CngesUiClosed()));
}

void MngmntCngesCntrller::run(){

    if(!isMngmentCngesUi)
    {
      CngesUi = new ManagementCnges(this);
      CngesUi->show();

      animation = new QPropertyAnimation(CngesUi, "geometry");
      animation->setDuration(300);
      animation->setEasingCurve(QEasingCurve::Linear);
      animation->setStartValue(QRectF(1900,100,CngesUi->width(),CngesUi->height()));
      animation->setEndValue(QRectF(260,100,CngesUi->width(),CngesUi->height()));
      animation->start(QAbstractAnimation::DeleteWhenStopped);

      isMngmentCngesUi=true;
    }

}

void MngmntCngesCntrller::onTableDmndeBtn(){
    CngesUi->getStackWidget()->setCurrentIndex(0);
}

void MngmntCngesCntrller::onTableCongesBtn(){
    CngesUi->getStackWidget()->setCurrentIndex(2);
}

void MngmntCngesCntrller::onTableValidationBtn(){
    CngesUi->getStackWidget()->setCurrentIndex(1);
}

void MngmntCngesCntrller::onTableModelEmployeBtn(){
    CngesUi->getStackWidget()->setCurrentIndex(3);
}

void MngmntCngesCntrller::onTableModelManagerBtn(){
    CngesUi->getStackWidget()->setCurrentIndex(4);
}

void MngmntCngesCntrller::closeMngmentCngesUi()
{
    if(isMngmentCngesUi){
      CngesUi->close();
      isMngmentCngesUi=false;
      emit CngesUiclosed();
    }

}

