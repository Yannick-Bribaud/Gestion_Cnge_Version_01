#include "addUserContrller.h"

addUserContrller::addUserContrller(QObject *parent)
{
    addUserUi=nullptr;
    connect(this,SIGNAL(addUserIsClosed()),parent,SLOT(addUserClosed()));

}

void addUserContrller::run(){
    if(!isAddUserShow){
        addUserUi = new AddUserUi(this);
        addUserUi->show();

        animation = new QPropertyAnimation(addUserUi, "geometry");
        animation->setDuration(380);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(QRectF(700,-900,addUserUi->width(),addUserUi->height()));
        animation->setEndValue(QRectF(700,150,addUserUi->width(),addUserUi->height()));
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        isAddUserShow=true;
    }

}

void addUserContrller::clickedOnButtonCancel(){
    if(isAddUserShow){   
     addUserUi->close();
     isAddUserShow=false;
      emit addUserIsClosed();
    }

}

void addUserContrller::ClickOnRadioBtnEmploye(){
    if(addUserUi->getIsCheckedRadioBtnEmploye()){
       addUserUi->setRadioBtnCheckedEmploye();
       setCngCntrller= new setCngeCntrller();
       setCngCntrller->run();
    }
}

void addUserContrller::ClickedOnBtnBox(){
    Messagebox->close();
}



void addUserContrller::verifyEmptyField(){

    if(addUserUi->getEditNom().isEmpty()){
        throw userExceptions("Remplissez le champs <Nom> s'il vous plait.");
    }
    if(addUserUi->getEditPrenom().isEmpty()){
        throw userExceptions("Remplissez le champs <Prénom> s'il vous plait.");
    }
    if(!addUserUi->getIsCheckedRadioBtnHomme() && !addUserUi->getIsCheckedRadioBtnFemme()
            && !addUserUi->getIsCheckedRadioBtnInconnu()){
        throw userExceptions("Selectionnez le <Genre> s'il vous plait");
    }
    if(addUserUi->getEditAdresse().isEmpty()){
        throw userExceptions("Remplissez le champs <Adresse> s'il vous plait");
    }
    if(addUserUi->getEditTelephone().isEmpty()){
       throw userExceptions("Remplissez le champs <Telephone> s'il vous plait");
    }
    if(addUserUi->getEditMatricule().isEmpty()){
          throw userExceptions("Remplissez le champs <Matricule> s'il vous plait");
     }
    if(addUserUi->getEditProfession().isEmpty()){
        throw userExceptions("Remplissez le champs <Profession> s'il vous plait");
    }
    if(addUserUi->getEditLogin().isEmpty()){
        throw userExceptions("Remplissez le champs <login> s'il vous plait");
    }
    if(addUserUi->getEditPassword().isEmpty()){
        throw userExceptions("Remplissez le champs <Password> s'il vous plait");
    }
    if(addUserUi->getEditEmail().isEmpty()){
        throw userExceptions("Remplissez le champs <Email> s'il vous plait");
    }
    if(!addUserUi->getIsCheckedRadioBtnManager() && !addUserUi->getIsCheckedRadioBtnEmploye()
        && !addUserUi->getIsCheckedRadioBtnAdmin() && !addUserUi->getIsCheckedRadioBtnDRH()){
         throw userExceptions("Selectionnez un <Status> s'il vous plait");
     }
}

void addUserContrller::createUser(){
    try {
          verifyEmptyField();
    }  catch (userExceptions e) {
       Messagebox = new Box("Field Invalid",0,e.getMessage(),this,nullptr);
       Messagebox->show();
    }
}
