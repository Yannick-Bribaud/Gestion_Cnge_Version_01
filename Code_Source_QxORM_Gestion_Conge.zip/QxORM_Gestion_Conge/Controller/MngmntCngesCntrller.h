#ifndef MNGMNTCNGESCNTRLLER_H
#define MNGMNTCNGESCNTRLLER_H
#include "Gui/ManagementCnges.h"
#include <QPropertyAnimation>

class MngmntCngesCntrller : public QObject
{
    Q_OBJECT

public:
    MngmntCngesCntrller(QObject *parent);
    void run();


signals:
    void CngesUiclosed();


private slots:
    void onTableDmndeBtn();
    void onTableCongesBtn();
    void onTableValidationBtn();
    void onTableModelEmployeBtn();
    void onTableModelManagerBtn();
    void closeMngmentCngesUi();


private:
    ManagementCnges * CngesUi;
    QPropertyAnimation * animation;
    bool isMngmentCngesUi=false;
};

#endif // MNGMNTCNGESCNTRLLER_H
