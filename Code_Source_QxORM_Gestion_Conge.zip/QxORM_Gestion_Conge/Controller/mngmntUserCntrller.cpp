#include "mngmntUserCntrller.h"

mngmntUserCntrller::mngmntUserCntrller(QObject * parent){
    mngUser=nullptr;
    connect(this,SIGNAL(closeMngrSignal()),parent,SLOT(MngUserisClosed()));
}

void mngmntUserCntrller::run(){
    if(!isMngUserShow){
        mngUser = new ManagementUser(this);
        mngUser->show();

        animation = new QPropertyAnimation(mngUser, "geometry");
        animation->setDuration(350);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(QRectF(1900,100,mngUser->width(),mngUser->height()));
        animation->setEndValue(QRectF(260,100,mngUser->width(),mngUser->height()));
        animation->start(QAbstractAnimation::DeleteWhenStopped);

        isMngUserShow=true;
    }
}

void mngmntUserCntrller::closeMngUserUi(){
    if(isMngUserShow){
      mngUser->close();
      isMngUserShow=false;
      emit closeMngrSignal();
    }
}

void mngmntUserCntrller::runAddUser(){
     if(!isAddUserShow){
     addUserCntrller=new addUserContrller(this);
     addUserCntrller->run();
     isAddUserShow=true;
    }
}

void mngmntUserCntrller::addUserClosed(){
    isAddUserShow=false;
}

void mngmntUserCntrller::onTableAdminBtn(){
  mngUser->getStackedWidget()->setCurrentIndex(4);
}

void mngmntUserCntrller::onTableProfessionnelBtn(){
    mngUser->getStackedWidget()->setCurrentIndex(0);
}

void mngmntUserCntrller::onTableEmployeBtn(){
   mngUser->getStackedWidget()->setCurrentIndex(1);
}

void mngmntUserCntrller::onTableManagerBtn(){
    mngUser->getStackedWidget()->setCurrentIndex(2);
}

void mngmntUserCntrller::onTableDrhBtn(){
    mngUser->getStackedWidget()->setCurrentIndex(3);
}
