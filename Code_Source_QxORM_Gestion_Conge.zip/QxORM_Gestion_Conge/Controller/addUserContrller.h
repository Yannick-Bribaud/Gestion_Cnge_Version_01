#ifndef ADDUSERCONTRLLER_H
#define ADDUSERCONTRLLER_H
#include "Gui/AddUserUi.h"
#include <QPropertyAnimation>
#include "Gui/setConges.h"
#include "Controller/setCngeCntrller.h"
#include "Exceptions/UserExceptions/userExceptions.h"
#include "Gui/box.h"
#include <QTimer>



class addUserContrller : public QObject
{
    Q_OBJECT
public:
    addUserContrller(QObject * parent);
    void run();
    void verifyEmptyField();

signals:
    void addUserIsClosed();

private slots:
    void createUser();
    void clickedOnButtonCancel();
    void ClickOnRadioBtnEmploye();
    void ClickedOnBtnBox();


private:
    AddUserUi * addUserUi;
    setCngeCntrller * setCngCntrller;
    QPropertyAnimation * animation;
    QTimer *timer;
    Box * Messagebox;
    bool isAddUserShow=false;
};

#endif // ADDUSERCONTRLLER_H
