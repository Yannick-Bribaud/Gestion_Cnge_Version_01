#include "setCngeCntrller.h"

setCngeCntrller::setCngeCntrller(){
  setCngesUi=nullptr;
   timer=new QTimer();
   connect(timer,SIGNAL(timeout()),this,SLOT(CloseSetCngeUI()));
}

void setCngeCntrller::run(){
    setCngesUi=new setConges(this);
    setCngesUi->show();

    animation = new QPropertyAnimation(setCngesUi, "geometry");
    animation->setDuration(350);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(700,1500,setCngesUi->width(),setCngesUi->height()));
    animation->setEndValue(QRectF(700,450,setCngesUi->width(),setCngesUi->height()));
    animation->start(QAbstractAnimation::DeleteWhenStopped);
}

QDate setCngeCntrller::getBeginDate(){
   beginDate=setCngesUi->getBeginDate();
    return beginDate;
}

quint8 setCngeCntrller::getDuration() {
    duration=setCngesUi->getDuration();
    return duration;
}

QDate setCngeCntrller::getEndDate(){
    EndDate=setCngesUi->getEndDate();
    return EndDate;
}

void setCngeCntrller::CloseSetCngeUI(){
    setCngesUi->close();
}

void setCngeCntrller::setPeriodAndDuration(){
  bool move=true;

  try {

        beginDate=getBeginDate();
        duration = getDuration();
        EndDate=getEndDate();

    }catch (userExceptions e) {
      MessageBox = new Box("Invalid value",0,e.getMessage(),this,nullptr);
      MessageBox->show();
      move=false;
    }


    if(move){
      timer->start(400);
      animation = new QPropertyAnimation(setCngesUi, "geometry");
      animation->setDuration(400);
      animation->setEasingCurve(QEasingCurve::InOutBack);
      animation->setStartValue(QRectF(700,450,setCngesUi->width(),setCngesUi->height()));
      animation->setEndValue(QRectF(700,1500,setCngesUi->width(),setCngesUi->height()));
      animation->start(QAbstractAnimation::DeleteWhenStopped);
    }
}

void setCngeCntrller::ClickedOnBtnBox(){
    MessageBox->close();
}


