#include "signincontroller.h"

SignInController::SignInController(){
    ui_SignIn=nullptr;
    service=nullptr;
    user=nullptr;

}

void SignInController::run(){
    ui_SignIn = new SignIn(this);
    ui_SignIn->show();

    animation = new QPropertyAnimation(ui_SignIn, "geometry");
    animation->setDuration(1000);
    animation->setEasingCurve(QEasingCurve::InOutCirc);
    animation->setStartValue(QRectF(0,0,ui_SignIn->width(),ui_SignIn->height()));
    animation->setEndValue(QRectF(800,400,ui_SignIn->width(),ui_SignIn->height()));
    animation->start(QAbstractAnimation::DeleteWhenStopped);


}

void SignInController::closeUi(){
   if(ui_SignIn->getIsOpen()){
       ui_SignIn->close();
    }
}

void SignInController::moveUi(){
    animation = new QPropertyAnimation(ui_SignIn, "geometry");
    animation->setDuration(800);
    animation->setEasingCurve(QEasingCurve::InOutCirc);
    animation->setStartValue(QRectF(800,400,ui_SignIn->width(),ui_SignIn->height()));
    animation->setEndValue(QRectF(2100,0,ui_SignIn->width(),ui_SignIn->height()));
    animation->start(QAbstractAnimation::DeleteWhenStopped);
}

void SignInController::ClickedOnSubmit(){
    try {
        service=new ServicesProfessionnels();
        user=service->Authentification(ui_SignIn->getUsername(),ui_SignIn->getPassword());

        if(user->getNom().isEmpty() && user->getPrenom().isEmpty()){
          box=new Box("Authentification/Not found",1,"Désolé,le username et/ou le mot de passe est/sont incorrect(s).\n veuillez réessayer svp!",this,NULL);
          box->show();
        }

    }catch(userExceptions e) {
        box=new Box("UserException/field empty",0,e.getMessage(),this,nullptr);
        box->show();

    }catch(ServicesExceptions ex){
        box=new Box("ServicesExceptions/Authentification",2,ex.getMessage(),this,nullptr);
        box->show();
    }
}

void SignInController::ClickedOnBtnBox(){
    if(box->getTextBtn()=="Retry"){
        ui_SignIn->setPassword("");
        ui_SignIn->setUsername("");
        box->close();
    }
    else{
    box->close();
  }



}
