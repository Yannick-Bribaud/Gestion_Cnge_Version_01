#ifndef SERVERCNTROLLER_H
#define SERVERCNTROLLER_H
#include "Gui/ServerUi.h"


class ServerCntroller : public QObject
{
    Q_OBJECT
public:
    ServerCntroller(QObject * parent);
    void run();

signals:
    void closeServerSignal();
private slots:
    void StartProcess();
    void execBtn();
    void CloseServerUi();

private:
    ServerUi * serverUi;
    bool isServerUishow=false;
};

#endif // SERVERCNTROLLER_H
