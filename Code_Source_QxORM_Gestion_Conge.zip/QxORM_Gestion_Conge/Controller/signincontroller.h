#ifndef SIGNINCONTROLLER_H
#define SIGNINCONTROLLER_H

#include <QObject>
#include <QPropertyAnimation>
#include "Gui/SignIn.h"
#include "Services/servicesprofessionnels.h"
#include "Entites/professionnel.h"
#include "Exceptions/ServicesExceptions/servicesexceptions.h"
#include "Exceptions/UserExceptions/userExceptions.h"
#include "Qx_Connect_db/qxdbconnect.h"
#include <QMessageBox>
#include "Gui/box.h"


class SignInController : public QObject
{
     Q_OBJECT

public:
    SignInController();
    virtual ~SignInController(){};
    void run();
    void closeUi();
    void moveUi();


private slots:
    void ClickedOnSubmit();
    void ClickedOnBtnBox();

private:
    SignIn * ui_SignIn;
    QPropertyAnimation * animation;
    ServicesProfessionnels * service;
    professionel_ptr user;
    Box *box;
};

#endif // SIGNINCONTROLLER_H
