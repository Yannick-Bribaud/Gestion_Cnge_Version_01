#ifndef ADMINCNTRLLER_H
#define ADMINCNTRLLER_H
#include "Gui/adminUI.h"
#include "Controller/mngmntUserCntrller.h"
#include "Controller/MngmntCngesCntrller.h"
#include "Controller/ServerCntroller.h"
#include <QObject>
#include <QPropertyAnimation>


class AdminCntrller :public QObject
{
    Q_OBJECT

public:
    AdminCntrller();
    void run();

private slots:
    void closeAdminUi();
    void runCntrlerUserMngmnt();
    void MngUserisClosed();
    void runCntrlerMngmntCnges();
    void CngesUiClosed();
    void runCntrlerServer();
    void closeServer();


private:
   adminUI * adminUi;
   mngmntUserCntrller * mngUser;
   MngmntCngesCntrller * Conges;
   ServerCntroller * serverCntroller;
   QPropertyAnimation * animationAdd;
   bool isAdminUIShow=false;
   bool isMngUseShow=false;
   bool isCngesUiShow=false;
   bool isServerUiShow=false;
};

#endif // ADMINCNTRLLER_H
