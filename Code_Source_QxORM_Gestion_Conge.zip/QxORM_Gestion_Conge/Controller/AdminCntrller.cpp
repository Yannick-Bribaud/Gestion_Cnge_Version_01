#include "AdminCntrller.h"

AdminCntrller::AdminCntrller(){
    adminUi=nullptr;
    Conges=nullptr;

}

void AdminCntrller::run(){
    if(!isAdminUIShow){
      adminUi = new adminUI(this);
      adminUi->show();
      isAdminUIShow=true;
    }
}

void AdminCntrller::closeAdminUi(){
    if(isAdminUIShow){
      adminUi->close();
      isAdminUIShow=false;
      delete adminUi;
    }
}

void AdminCntrller::runCntrlerUserMngmnt(){
    if(!isMngUseShow){
        mngUser=new mngmntUserCntrller(this);
        mngUser->run();
        isMngUseShow=true;
    }

}

void AdminCntrller::MngUserisClosed(){
    isMngUseShow=false;
     delete mngUser;
}

void AdminCntrller::runCntrlerMngmntCnges(){
    if(!isCngesUiShow){
      Conges=new MngmntCngesCntrller(this);
      Conges->run();
      isCngesUiShow=true;
    }

}

void AdminCntrller::CngesUiClosed(){
     isCngesUiShow=false;
     delete Conges;
}

void AdminCntrller::runCntrlerServer()
{
    if(!isServerUiShow){
       serverCntroller = new ServerCntroller(this);
       serverCntroller->run();
       isServerUiShow=true;
    }

}

void AdminCntrller::closeServer(){
    isServerUiShow=false;
    delete serverCntroller;
}
