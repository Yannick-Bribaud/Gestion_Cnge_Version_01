#ifndef MNGMNTUSERCNTRLLER_H
#define MNGMNTUSERCNTRLLER_H
#include "Gui/ManagementUser.h"
#include "Controller/addUserContrller.h"
#include <QPropertyAnimation>


class mngmntUserCntrller : public QObject
{
    Q_OBJECT

public:
    mngmntUserCntrller(QObject * parent);
    void run();

signals:
    void closeMngrSignal();

private slots:
    void closeMngUserUi();
    void runAddUser();
    void addUserClosed();
    void onTableAdminBtn();
    void onTableProfessionnelBtn();
    void onTableEmployeBtn();
    void onTableManagerBtn();
    void onTableDrhBtn();


private:
    ManagementUser * mngUser;
    addUserContrller * addUserCntrller;
    QPropertyAnimation * animation;
    bool isMngUserShow=false;
    bool isAddUserShow=false;
};

#endif // MNGMNTUSERCNTRLLER_H
