#include "ProfileUI.h"
#include "ui_ProfileUI.h"

ProfileUI::ProfileUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProfileUI)
{

    ui->setupUi(this);
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->setWindowModified(true);

    ui->CloseProfile_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    connect(ui->Close_Button,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->CloseProfile_Button,SIGNAL(clicked()),this,SLOT(close()));
    animationWidgetProfil();
}



void ProfileUI::animationWidgetProfil(){

    animationLabel= new QPropertyAnimation(ui->lastname_label,"geometry");
    animationLabel->setDuration(500);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,50,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->lastname_lineEdit,"geometry");
    animation->setDuration(600);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,80,240,35));
    animation->start();


    animationLabel= new QPropertyAnimation(ui->firstname_label,"geometry");
    animationLabel->setDuration(700);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,140,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->firstname_lineEdit,"geometry");
    animation->setDuration(800);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,170,240,35));
    animation->start();

    animationLabel= new QPropertyAnimation(ui->Genre_label,"geometry");
    animationLabel->setDuration(800);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,225,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->genre_lineEdit,"geometry");
    animation->setDuration(900);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,255,240,35));
    animation->start();


    animationLabel= new QPropertyAnimation(ui->Profession_label,"geometry");
    animationLabel->setDuration(900);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,320,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->Profession_lineEdit,"geometry");
    animation->setDuration(1000);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,350,240,35));
    animation->start();


    animationLabel= new QPropertyAnimation(ui->status_label,"geometry");
    animationLabel->setDuration(1000);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,410,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->status_lineEdit,"geometry");
    animation->setDuration(1100);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,440,240,35));
    animation->start();

    animationLabel= new QPropertyAnimation(ui->email_label,"geometry");
    animationLabel->setDuration(1200);
    animationLabel->setEasingCurve(QEasingCurve::InExpo);
    animationLabel->setStartValue(QRectF(60,700,200,25));
    animationLabel->setEndValue(QRectF(60,500,200,25));
    animationLabel->start();

    animation = new QPropertyAnimation(ui->email_lineEdit,"geometry");
    animation->setDuration(1300);
    animation->setEasingCurve(QEasingCurve::InExpo);
    animation->setStartValue(QRectF(60,700,240,35));
    animation->setEndValue(QRectF(60,530,240,35));
    animation->start();

    animation = new QPropertyAnimation(ui->Close_Button,"geometry");
    animation->setDuration(900);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(280,0,0,40));
    animation->setEndValue(QRectF(280,590,110,40));
    animation->start();
}

/*
ProfileUI::ProfileUI(QObject *user, QWidget *parent):
    QWidget(parent),
    ui(new Ui::ProfileUI)
{
    ui->setupUi(this);
    ui->CloseProfile_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    connect(ui->CloseProfile_Button,SIGNAL(clicked()),this,SLOT(close()));
}*/

ProfileUI::~ProfileUI()
{
    delete ui;
}
