#include "UILogin.h"
#include "ui_UILogin.h"
#include "QPixmap"

UILogin::UILogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UILogin)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::Widget | Qt::MSWindowsFixedSizeDialogHint);
    SignInOpen=false;

    setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    timer=new QTimer();

    Exetendlabel();
    frameButtons();
    connect(ui->ButtonSignIn, SIGNAL(clicked()),this,SLOT(OnButtonSignIn()));
    connect(ui->ButtonCancel, SIGNAL(clicked()),this,SLOT(OnButtonCancel()));
    connect(timer, SIGNAL(timeout()), this, SLOT(closeBothWidget()));
}


UILogin::~UILogin(){
    SignInOpen=false;
    delete ui;
}

void UILogin::frameButtons()
{
    m_height=ui->frameBottomContent->height();
    int Extendheight = 237;
    animation = new QPropertyAnimation(ui->frameBottomContent,"maximumHeight");
    animation->setDuration(1200);
    animation->setEasingCurve(QEasingCurve::InQuad);
    animation->setStartValue(m_height);
    animation->setEndValue(Extendheight);
    animation->start();
}

void UILogin::Exetendlabel(){

    m_Width=181; m_height=181;
    animation = new QPropertyAnimation(ui->label, "geometry");
    animation->setDuration(1000);
    animation->setEasingCurve(QEasingCurve::InQuad);
    animation->setStartValue(QRectF(0,0,ui->label->width(),ui->label->height()));
    animation->setEndValue(QRectF(15,31,m_Width,m_height));
    animation->start();
}

void UILogin::moveUi(){
    animation = new QPropertyAnimation(this, "geometry");
    animation->setDuration(800);
    animation->setEasingCurve(QEasingCurve::InOutCirc);
    animation->setStartValue(QRectF(800,400,this->width(),this->height()));
    animation->setEndValue(QRectF(-500,0,this->width(),this->height()));
    animation->start(QAbstractAnimation::DeleteWhenStopped);
}


void UILogin::OnButtonSignIn(){
    if(!SignInOpen){
      signInCntrler.run();
      SignInOpen=true;
    }
}

void UILogin::OnButtonCancel(){
     if(SignInOpen){
       timer->start(1900);
       signInCntrler.moveUi();
       this->moveUi();
    }else{
      timer->start(1000);
       this->moveUi();
    }
}

void UILogin::closeBothWidget(){
    if(SignInOpen){
      signInCntrler.closeUi();
      this->close();
    }
    else{
      this->close();
    }
}


void UILogin::mousePressEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton){
        MouseOff=true;
    }
}

void UILogin::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->Close){
      MouseOff=false;
    }

}

void UILogin::mouseMoveEvent(QMouseEvent *event){
    if(MouseOff){
      mousePoint=event->globalPos();
      move(mousePoint);
    }
}


