#ifndef SIGNIN_H
#define SIGNIN_H

#include <QWidget>
#include <QLineEdit>
#include <QMessageBox>
#include <QMouseEvent>

namespace Ui {
class SignIn;
}

class SignIn : public QWidget
{
    Q_OBJECT

public:
    explicit SignIn(QWidget *parent = nullptr);
    SignIn(QObject *SignInController);
    ~SignIn();

    QString getUsername();
    QString getPassword();

    void setUsername(const QString & username);
    void setPassword(const QString & password);
    bool getIsOpen()const{ return ui_isOpen; };

protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent * event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent * event);

private:
    Ui::SignIn * ui;
    QString username;
    QString password;
    bool ui_isOpen;
    bool MouseOff=false;
    bool rdBtn;

};

#endif // SIGNIN_H
