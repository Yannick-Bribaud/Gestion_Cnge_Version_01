#ifndef ADMINUI_H
#define ADMINUI_H

#include <QWidget>
#include <QMouseEvent>
#include <QMessageBox>
#include <QPropertyAnimation>
#include <QTimer>
#include "Gui/ProfileUI.h"
#include "Gui/ServerUi.h"


namespace Ui {
class adminUI;
}

class adminUI : public QWidget
{
    Q_OBJECT

public:
    explicit adminUI(QWidget *parent = nullptr);
    explicit adminUI(QObject * adminCntrller);
    void Initialise();
    void VisibleMenu();
    void hideMenu(int timer);
    void setDate();
    void setAnimationInScrollArea();
    void MethodeOfMaxAndMinFrame();

    ~adminUI();

private slots:
    void OnCloseUIBtn();
    void OnMinimizeUIBtn();
    void OnMaximizeUIBtn();
    void ShowMenu();
    void onBackToMenu();
    void setTime();
    void onProfilBtn();
    void OnServerBtn();




protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent * event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent * event);

private:
    Ui::adminUI *ui;
    ProfileUI * profilUi;
    QPropertyAnimation *animation;
    QPropertyAnimation *animationLabel;
    quint8 statusWindows;
    bool windowShouldClose();
    bool isMenuFrameShow;
    bool isMenuShow;
    bool isServerShow;
    bool MouseOff=false;
    int labelWidth; int labelHeight;
    int BtnWidth; int BtnHeight;
    QTimer * timer;
    QTime time; QDate date;
    QString time_Text;
    ServerUi * server_Ui;

};

#endif // ADMINUI_H
