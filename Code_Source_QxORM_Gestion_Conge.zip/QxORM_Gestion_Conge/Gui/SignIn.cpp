#include "SignIn.h"
#include "ui_SignIn.h"

SignIn::SignIn(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SignIn)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
}


SignIn::SignIn(QObject * SignInController):
    ui(new Ui::SignIn)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui_isOpen=true;
    connect(ui->ButtonSubmit,SIGNAL(clicked()),SignInController,SLOT(ClickedOnSubmit()));
}

SignIn::~SignIn(){
    ui_isOpen=false;
    delete ui;
}

QString SignIn::getUsername(){
    this->username = ui->lineEditUsername->text();
    return username;
}

QString SignIn::getPassword() {
    this->password=ui->lineEditPassword->text();
    return password;
}


void SignIn::setUsername(const QString & username){
    ui->lineEditUsername->setText(username);
}

void SignIn::setPassword(const QString & password){
    ui->lineEditPassword->setText(password);
}

void SignIn::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        MouseOff=true;
    }
}

void SignIn::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
      MouseOff=false;
    }
}

void SignIn::mouseMoveEvent(QMouseEvent *event){
    if(MouseOff){
      mousePoint=event->globalPos();
      move(mousePoint);
    }
}
