#ifndef MANAGEMENTCNGES_H
#define MANAGEMENTCNGES_H

#include <QWidget>
#include <QPoint>
#include <QMouseEvent>
#include <QPropertyAnimation>
#include <QAction>
#include <QMenu>
#include <QStackedWidget>



namespace Ui {
class ManagementCnges;
}

class ManagementCnges : public QWidget
{
    Q_OBJECT

public:
    explicit ManagementCnges(QWidget *parent = nullptr);
    explicit ManagementCnges(QObject * leaveController);
    void initialise();
    QStackedWidget * getStackWidget();

    ~ManagementCnges();

protected:
    QPoint mousePoint;
    void mouseReleaseEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);

private slots:
    void maximizeWidget();
    void minimizeWidget();
    void onChevronButton();

private:
    Ui::ManagementCnges *ui;
    bool mouseOff;
    int labelWidth;
    int labelHeight;
    int statusWindows;
    bool showframeOfTopMenus;
    QPropertyAnimation * animation;
    QAction * supprimerDemande;
    QAction * modifierDemande;
    QList<QAction *>listeAction_dmd;
};



#endif // MANAGEMENTCNGES_H
