#include "box.h"
#include "ui_box.h"
#include <QPixmap>

Box::Box(QString Title, quint8 typeErreur, QString message, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Box)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButtonCancel->setIcon(QIcon(":/img/Images/cancel_96px.png"));

    setTitle(Title);
    setTypeErreur(typeErreur);
    setMessage(message);
    setAttributeOfBox();

    connect(ui->ButtonBox,SIGNAL(clicked()),this,SLOT(clickedOnCancelBtn()));
    connect(ui->pushButtonCancel,SIGNAL(clicked()),this,SLOT(clickedOnCancelBtn()));

}

Box::Box(QString Title, quint8 typeErreur, QString message, QObject *Controlleur, QWidget *parent):
    QDialog(parent),
    ui(new Ui::Box)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButtonCancel->setIcon(QIcon(":/img/Images/cancel_96px.png"));

    setTitle(Title);
    setTypeErreur(typeErreur);
    setMessage(message);
    setAttributeOfBox();

    connect(ui->ButtonBox,SIGNAL(clicked()),Controlleur,SLOT(ClickedOnBtnBox()));
    connect(ui->pushButtonCancel,SIGNAL(clicked()),this,SLOT(clickedOnCancelBtn()));

}



void Box::setAttributeOfBox()
{
    switch (typeErreur) {

    case 0:{

            ui->labelTitle->setText(Title);
            Width=ui->Label_Icone->width(); height=ui->Label_Icone->height();
            QPixmap pix(":/img/Images/stop_sign_96px.png");
            ui->Label_Icone->setPixmap(pix.scaled(Width,height,Qt::KeepAspectRatio));
            ui->labelMessage->setText(message);
            ui->ButtonBox->setText("OK");
        break;
    }

    case 1:{
            ui->labelTitle->setText(Title);
            Width=ui->Label_Icone->width(); height=ui->Label_Icone->height();
            QPixmap pix(":/img/Images/denied_80px.png");
            ui->Label_Icone->setPixmap(pix.scaled(Width,height,Qt::KeepAspectRatio));
            ui->labelMessage->setText(message);
            ui->ButtonBox->setText("Retry");
            break;
      }

     case 2:{
            ui->labelTitle->setText(Title);
            Width=ui->Label_Icone->width(); height=ui->Label_Icone->height();
            QPixmap pix(":/img/Images/error_96px.png");
            ui->Label_Icone->setPixmap(pix.scaled(Width,height,Qt::KeepAspectRatio));
            ui->labelMessage->setText(message);
            ui->ButtonBox->setText("OK");
        break;
    }

    }
}

void Box::setMessage(const QString & mesage){
    this->message=mesage;
}

void Box::setTitle(const QString &Title){
    this->Title = Title;
}

void Box::setTypeErreur(const quint8 typeErreur){
    this->typeErreur=typeErreur;
}

QString Box::getTextBtn() const{
   return ui->ButtonBox->text();
}

Box::~Box(){
   delete ui;
}

void Box::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        MouseOff=true;
    }
}

void Box::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
      MouseOff=false;
    }
}

void Box::mouseMoveEvent(QMouseEvent *event){
    if(MouseOff){
        mousePoint=event->globalPos();
        move(mousePoint);
    }
}

void Box::clickedOnCancelBtn(){
    this->close();
}

void Box::clickedOnBtnBox(){
    this->close();
}


