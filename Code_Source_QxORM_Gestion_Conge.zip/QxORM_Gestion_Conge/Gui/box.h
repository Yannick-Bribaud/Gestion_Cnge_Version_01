#ifndef BOX_H
#define BOX_H

#include <QDialog>
#include <QMouseEvent>
#include <QPoint>


namespace Ui {
class Box;
}

class Box : public QDialog
{
    Q_OBJECT

public:
    explicit Box(QString Title, quint8 typeErreur, QString message,QWidget *parent = nullptr);
    explicit Box(QString Title, quint8 typeErreur, QString message,QObject * Controlleur,QWidget *parent = nullptr);

    void setAttributeOfBox();
    void setMessage(const QString & mesage);
    void setTitle(const QString & Title);
    void setTypeErreur(const quint8 typeErreur);
    QString getMessage()const{ return message;}
    QString getTitle() const {return Title;}
    quint8 getTypeErreur() const {return typeErreur;}
    QString getTextBtn()const;

    ~Box();

protected:
  QPoint mousePoint;
  void mousePressEvent(QMouseEvent * event);
  void mouseReleaseEvent(QMouseEvent * event);
  void mouseMoveEvent(QMouseEvent * event);

private slots:
  void clickedOnCancelBtn();

  void clickedOnBtnBox();

private:
    Ui::Box *ui;
    bool MouseOff=false;
    QString message;
    QString Title;
    quint8 typeErreur;
    QString textBtn;
    int Width;
    int height;

};

#endif // BOX_H
