#include "ServerUi.h"
#include "ui_ServerUi.h"

ServerUi::ServerUi(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ServerUi)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    mouseOff=false;

    notif_System=new QSystemTrayIcon(this);
    notif_System->setIcon(QIcon(":/img/Images/serverTray_96px.png"));
    notif_System->setVisible(true);

    ui->close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    ui->minimize_Button->setIcon(QIcon(":/img/Images/minimize_window_48px.png"));
    ui->exec_Button->setIcon(QIcon(":/img/Images/program_96px.png"));

    connect(&server_Process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),this,
        [=](int exitCode, QProcess::ExitStatus){
        notif_System->showMessage(tr("Notification"),tr("Programme serveur arrêté").arg(exitCode),QIcon(":/img/Images/info_squared_96px.png"));
      });

    connect(&server_Process,SIGNAL(started()),this,SLOT(StartProcess()));
    connect(ui->minimize_Button,SIGNAL(clicked()),this,SLOT(onMinimizeBtn()));
    connect(ui->close_Button,SIGNAL(clicked()),parent,SLOT(closeServer()));
    connect(ui->exec_Button,SIGNAL(clicked()),this,SLOT(execBtn()));

}

ServerUi::ServerUi(QObject *Controller):
    ui(new Ui::ServerUi)
{
    ui->setupUi(this);
    initialise();

    connect(&server_Process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),this,
        [=](int exitCode, QProcess::ExitStatus){
        notif_System->showMessage(tr("Notification"),tr("Programme serveur arrêté").arg(exitCode),QIcon(":/img/Images/info_squared_96px.png"));
      });

    connect(ui->minimize_Button,SIGNAL(clicked()),this,SLOT(onMinimizeBtn()));
    connect(&server_Process,SIGNAL(started()),Controller,SLOT(StartProcess()));
    connect(ui->close_Button,SIGNAL(clicked()),Controller,SLOT(CloseServerUi()));
    connect(ui->exec_Button,SIGNAL(clicked()),Controller,SLOT(execBtn()));
}

void ServerUi::initialise()
{
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    mouseOff=false;

    notif_System=new QSystemTrayIcon(this);
    notif_System->setIcon(QIcon(":/img/Images/serverTray_96px.png"));
    notif_System->setVisible(true);

    ui->close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    ui->minimize_Button->setIcon(QIcon(":/img/Images/minimize_window_48px.png"));
    ui->exec_Button->setIcon(QIcon(":/img/Images/play_96px.png"));

}

ServerUi::~ServerUi(){
    delete ui;
}



void ServerUi::onMinimizeBtn(){
    this->showMinimized();
}

void ServerUi::mousePressEvent(QMouseEvent *event){
   if(event->button()==Qt::LeftButton){
       mouseOff=true;
   }

}

void ServerUi::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
      mouseOff=false;
    }
}

void ServerUi::mouseMoveEvent(QMouseEvent *event){
    if(mouseOff){
        MousePoint=event->globalPos();
        move(MousePoint);
    }
}

