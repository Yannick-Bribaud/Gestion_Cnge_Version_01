#ifndef UILOGIN_H
#define UILOGIN_H

#include <QWidget>
#include <QTimer>
#include <QPropertyAnimation>
#include <QMouseEvent>
#include "SignIn.h"
#include "Controller/signincontroller.h"

namespace Ui {
class UILogin;
}

class UILogin : public QWidget
{
    Q_OBJECT

public:
    explicit UILogin(QWidget *parent = nullptr);
    void frameButtons();
    void Exetendlabel();
    void moveUi();
    ~UILogin();

private slots:
    void OnButtonSignIn();
    void OnButtonCancel();
    void closeBothWidget();

protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent * event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent * event);

private:
    Ui::UILogin *ui;
    SignIn * UI_SignIn;
    bool SignInOpen;
    bool MouseOff=false;

    int m_Width;
    int m_height;
    QTimer * timer;
    SignInController signInCntrler;
    QPropertyAnimation * animation;
};

#endif // UILOGIN_H
