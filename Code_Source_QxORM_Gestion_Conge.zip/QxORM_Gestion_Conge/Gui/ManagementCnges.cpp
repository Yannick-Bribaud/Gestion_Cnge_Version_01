#include "ManagementCnges.h"
#include "ui_ManagementCnges.h"

ManagementCnges::ManagementCnges(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagementCnges)
{
    ui->setupUi(this);
    initialise();

    connect(ui->close_Button,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->TabDmnde_Button,SIGNAL(clicked()),this,SLOT(onTableDmndeBtn()));
    connect(ui->TabCnges_Button,SIGNAL(clicked()),this,SLOT(onTableCongesBtn()));
    connect(ui->TabValidation_Button,SIGNAL(clicked()),this,SLOT(onTableValidationBtn()));
    connect(ui->TabMdlEmploye_Button,SIGNAL(clicked()),this,SLOT(onTableModelEmployeBtn()));
    connect(ui->TabMdlMngr_Button,SIGNAL(clicked()),this,SLOT(onTableModelManagerBtn()));
}

ManagementCnges::ManagementCnges(QObject *leaveController):
    ui(new Ui::ManagementCnges)
{
      ui->setupUi(this);
      initialise();
      connect(ui->close_Button,SIGNAL(clicked()),leaveController,SLOT(closeMngmentCngesUi()));
      connect(ui->TabDmnde_Button,SIGNAL(clicked()),leaveController,SLOT(onTableDmndeBtn()));
      connect(ui->TabCnges_Button,SIGNAL(clicked()),leaveController,SLOT(onTableCongesBtn()));
      connect(ui->TabValidation_Button,SIGNAL(clicked()),leaveController,SLOT(onTableValidationBtn()));
      connect(ui->TabMdlEmploye_Button,SIGNAL(clicked()),leaveController,SLOT(onTableModelEmployeBtn()));
      connect(ui->TabMdlMngr_Button,SIGNAL(clicked()),leaveController,SLOT(onTableModelManagerBtn()));
}



void ManagementCnges::initialise(){
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);

     labelWidth=ui->label_IconeApp->width(); labelHeight=ui->label_IconeApp->height();
     QPixmap pix(":/img/Images/logo-req.png");
     ui->label_IconeApp->setPixmap(pix.scaled(labelWidth,labelHeight,Qt::KeepAspectRatio));

    ui->close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    ui->extend_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
    ui->rediusWindow_Button->setIcon(QIcon(":/img/Images/minimize_window_48px.png"));
    ui->Chevron_Button->setIcon(QIcon(":/img/Images/chevron_down_48px.png"));

    ui->tableWidget_demande->setColumnWidth(0,150);
    ui->tableWidget_demande->setColumnWidth(1,200);
    ui->tableWidget_demande->setColumnWidth(2,200);
    ui->tableWidget_demande->setColumnWidth(3,200);
    ui->tableWidget_demande->setColumnWidth(4,200);
    ui->tableWidget_demande->setColumnWidth(5,100);
    ui->tableWidget_demande->setColumnWidth(6,200);
    ui->tableWidget_demande->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_validation->setColumnWidth(0,75);
    ui->tableWidget_validation->setColumnWidth(1,200);
    ui->tableWidget_validation->setColumnWidth(2,200);
    ui->tableWidget_validation->setColumnWidth(3,200);
    ui->tableWidget_validation->setColumnWidth(4,200);
    ui->tableWidget_validation->setColumnWidth(5,100);
    ui->tableWidget_validation->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_Conges->setColumnWidth(0,75);
    ui->tableWidget_Conges->setColumnWidth(1,200);
    ui->tableWidget_Conges->setColumnWidth(2,200);
    ui->tableWidget_Conges->setColumnWidth(3,75);
    ui->tableWidget_Conges->setColumnWidth(4,200);
    ui->tableWidget_Conges->setContextMenuPolicy(Qt::ActionsContextMenu);


    ui->tableWidget_ModelEmploye->setColumnWidth(0,75);
    ui->tableWidget_ModelEmploye->setColumnWidth(1,200);
    ui->tableWidget_ModelEmploye->setColumnWidth(2,200);
    ui->tableWidget_ModelEmploye->setColumnWidth(3,200);
    ui->tableWidget_ModelEmploye->setColumnWidth(4,200);
    ui->tableWidget_ModelEmploye->setColumnWidth(5,150);
    ui->tableWidget_ModelEmploye->setColumnWidth(6,150);
    ui->tableWidget_ModelEmploye->setColumnWidth(7,200);
    ui->tableWidget_ModelEmploye->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_ModelManager->setColumnWidth(0,150);
    ui->tableWidget_ModelManager->setColumnWidth(1,200);
    ui->tableWidget_ModelManager->setColumnWidth(2,200);
    ui->tableWidget_ModelManager->setColumnWidth(3,200);
    ui->tableWidget_ModelManager->setColumnWidth(4,120);
    ui->tableWidget_ModelManager->setColumnWidth(5,140);
    ui->tableWidget_ModelManager->setColumnWidth(6,150);
    ui->tableWidget_ModelManager->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->TabDmnde_Button->setIcon(QIcon(":/img/Images/table_96px.png"));
    ui->TabValidation_Button->setIcon(QIcon(":/img/Images/table_96px.png"));
    ui->TabCnges_Button->setIcon(QIcon(":/img/Images/table_96px.png"));
    ui->TabMdlEmploye_Button->setIcon(QIcon(":/img/Images/table_96px.png"));
    ui->TabMdlMngr_Button->setIcon(QIcon(":/img/Images/table_96px.png"));


    supprimerDemande= new QAction("Supprimer une demande");
    modifierDemande = new QAction("Modifier une demande");

    supprimerDemande->setIcon(QIcon(":/img/Images/delete_trash2_96px.png"));
    modifierDemande->setIcon(QIcon(":/img/Images/editNew_96px.png"));

    listeAction_dmd.append(modifierDemande);
    listeAction_dmd.append(supprimerDemande);

    ui->tableWidget_demande->addActions(listeAction_dmd);

    connect(ui->rediusWindow_Button,SIGNAL(clicked()),this,SLOT(minimizeWidget()));
    connect(ui->extend_Button,SIGNAL(clicked()),this,SLOT(maximizeWidget()));
    connect(ui->Chevron_Button,SIGNAL(clicked()),this,SLOT(onChevronButton()));
    statusWindows=0; showframeOfTopMenus=false;
    ui->stackedWidget->setCurrentIndex(0);
}

QStackedWidget * ManagementCnges::getStackWidget(){
    return ui->stackedWidget;
}


ManagementCnges::~ManagementCnges(){
    delete ui;
}

void ManagementCnges::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close)
        mouseOff=false;
}

void ManagementCnges::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton)
        mouseOff=true;
}

void ManagementCnges::mouseMoveEvent(QMouseEvent *event){
     if(mouseOff){
        mousePoint=event->globalPos();
        move(mousePoint);
     }
}


void ManagementCnges::maximizeWidget()
{
    if(statusWindows==0){
        this->showMaximized();
        ui->extend_Button->setIcon(QIcon(":/img/Images/restore_down_48px.png"));
        statusWindows=1;
     }
    else{
        this->showNormal();
        ui->extend_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
        statusWindows=0;
    }

}

void ManagementCnges::minimizeWidget(){
    this->showMinimized();
}

void ManagementCnges::onChevronButton()
{
    if(showframeOfTopMenus){
        animation=new QPropertyAnimation(ui->frame_Collapse,"maximumHeight");
        animation->setDuration(300);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(120);
        animation->setEndValue(0);
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        showframeOfTopMenus=false;
        ui->Chevron_Button->setIcon(QIcon(":/img/Images/chevron_down_48px.png"));
    }
    else{
        animation=new QPropertyAnimation(ui->frame_Collapse,"maximumHeight");
        animation->setDuration(300);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(0);
        animation->setEndValue(120);
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        showframeOfTopMenus=true;
        ui->Chevron_Button->setIcon(QIcon(":/img/Images/chevron_up_48px.png"));
    }
}
