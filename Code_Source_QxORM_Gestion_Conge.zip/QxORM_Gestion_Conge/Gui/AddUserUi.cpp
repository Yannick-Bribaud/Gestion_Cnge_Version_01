#include "AddUserUi.h"
#include "ui_AddUserUi.h"

AddUserUi::AddUserUi(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddUserUi)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->addUser_Button->setIcon(QIcon(":/img/Images/approval_96px.png"));
    MouseOff=false;
    connect(ui->Cancel_Button,SIGNAL(clicked()),this,SLOT(close()));

}

AddUserUi::AddUserUi(QObject * addUserController):
    ui(new Ui::AddUserUi)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->addUser_Button->setIcon(QIcon(":/img/Images/approval_96px.png"));
    MouseOff=false;
    connect(ui->Cancel_Button,SIGNAL(clicked()),addUserController,SLOT(clickedOnButtonCancel()));
    connect(ui->radioButton_Employe,SIGNAL(clicked()),addUserController,SLOT(ClickOnRadioBtnEmploye()));
    connect(ui->addUser_Button,SIGNAL(clicked()),addUserController,SLOT(createUser()));


}



void AddUserUi::setRadioBtnCheckedEmploye(){
  ui->radioButton_Employe->setChecked(true);
}

void AddUserUi::setRadioBtnCheckedManager(){
  ui->radioButton_Manager->setChecked(true);
}

void AddUserUi::setRadioBtnCheckedAdmin(){
   ui->radioButton_Admin->setChecked(true);
}

void AddUserUi::setRadioBtnCheckedDRH(){
   ui->radioButton_DRH->setChecked(true);
}

bool AddUserUi::getIsCheckedRadioBtnEmploye(){
  return ui->radioButton_Employe->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnManager(){
  return ui->radioButton_Manager->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnAdmin(){
   return ui->radioButton_Admin->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnDRH(){
    return ui->radioButton_DRH->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnHomme(){
    return ui->radioButton_Male->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnFemme(){
    return ui->radioButton_Female->isChecked();
}

bool AddUserUi::getIsCheckedRadioBtnInconnu(){
    return ui->radioButton_Unknwo->isChecked();
}

QString AddUserUi::getEditNom(){
    return ui->lineEdit_NameUser->text();
}

QString AddUserUi::getEditPrenom(){
return ui->lineEdit_FirstName->text();
}

QDate AddUserUi::getEditDateNaissance(){
    return ui->dateEdit_BirthDayUser->date();
}

Genre::EnumGenre AddUserUi::getEditGenre()
{
    if(ui->radioButton_Male->isChecked()){
        return Genre::EnumGenre::Homme;
    }
    else if(ui->radioButton_Female->isChecked()){
        return Genre::EnumGenre::Femme;
     }
    return Genre::EnumGenre::Inconnu;
}

QString AddUserUi::getEditAdresse(){
    return ui->lineEdit_AdresseUser->text();
}

QString AddUserUi::getEditTelephone(){
    return ui->lineEdit_Telephone->text();
}

QString AddUserUi::getEditMatricule(){
    return ui->lineEdit_Matricule->text();
}

QString AddUserUi::getEditLogin(){
    return ui->lineEdit_Login->text();
}

QString AddUserUi::getEditProfession(){
    return ui->lineEdit_ProfessionUser->text();
}

QString AddUserUi::getEditPassword(){
    return ui->lineEdit_Password->text();
}

QString AddUserUi::getEditEmail(){
    return ui->lineEdit_Email->text();
}

Status::EnumStatus AddUserUi::getEditStatus(){
    if(ui->radioButton_Manager->isChecked()){
        return Status::EnumStatus::Manager;
    }
    else if(ui->radioButton_Employe->isChecked()){
        return Status::EnumStatus::Employe;
    }
    else if(ui->radioButton_Admin->isChecked()){
        return Status::EnumStatus::Administration;
    }
  return Status::EnumStatus::Directeur_Ressources_Humaines;
}


AddUserUi::~AddUserUi(){
    delete ui;
}

void AddUserUi::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        MouseOff=true;
    }
}

void AddUserUi::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close)
        MouseOff=false;
}

void AddUserUi::mouseMoveEvent(QMouseEvent *event){
    if(MouseOff){
        mousePoint = event->globalPos();
        move(mousePoint);
    }
}



