#include "adminUI.h"
#include "ui_adminUI.h"

adminUI::adminUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::adminUI)
{
    ui->setupUi(this);

    Initialise();
    connect(ui->CloseUI_Button,SIGNAL(clicked()),this,SLOT(OnCloseUIBtn()));

}

adminUI::adminUI(QObject *adminCntrller):
    ui(new Ui::adminUI)
{
    ui->setupUi(this);
      Initialise();
      connect(ui->CloseUI_Button,SIGNAL(clicked()),adminCntrller,SLOT(closeAdminUi()));
      connect(ui->userManagement_Button,SIGNAL(clicked()),adminCntrller,SLOT(runCntrlerUserMngmnt()));
      connect(ui->leaves_Button,SIGNAL(clicked()),adminCntrller,SLOT(runCntrlerMngmntCnges()));
      connect(ui->server_Button,SIGNAL(clicked()),adminCntrller,SLOT(runCntrlerServer()));
}


void adminUI::Initialise()
{
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    timer=new QTimer(this); setDate();isServerShow=false;


    ui->ExtendUI_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
    ui->CloseUI_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    ui->ReductUI_Button->setIcon(QIcon(":/img/Images/minimize_window_48px.png"));
    ui->Menu_Button->setIcon(QIcon(":/img/Images/menu_128px.png"));

    //All buttons
    ui->home_Button->setIcon(QIcon(":/img/Images/home_48px.png"));
    ui->server_Button->setIcon(QIcon(":/img/Images/server_52px.png"));
    ui->userManagement_Button->setIcon(QIcon(":/img/Images/management_48px.png"));
    ui->ShowMenu_Button->setIcon(QIcon(":/img/Images/back_to_48px.png"));
    ui->Profile_Button->setIcon(QIcon(":/img/Images/male_user_48px.png"));
    ui->research_Button->setIcon(QIcon(":/img/Images/search_more_64px.png"));
    ui->leaves_Button->setIcon(QIcon(":/img/Images/leave_100px.png"));
    ui->File_Button->setIcon(QIcon(":/img/Images/file_submodule_96px.png"));
    ui->Calendar_Button->setIcon(QIcon(":/img/Images/tear-off_calendar_96px.png"));
    ui->Broadcast_Button->setIcon(QIcon(":/img/Images/shared_mail_96px.png"));
    ui->logFile_Button->setIcon(QIcon(":/img/Images/log_48px.png"));
    ui->ConnectToServer_Button->setIcon(QIcon(":/img/Images/thin_client_96px.png"));
    ui->DisconectFromServer_Button->setIcon(QIcon(":/img/Images/disconnected_96px.png"));

        //Button menu
    ui->userManagement_Button->setVisible(false);
    ui->server_Button->setVisible(false);
    ui->home_Button->setVisible(false);
    ui->leaves_Button->setVisible(false);
         //label Menu
    ui->label_Home->setVisible(false);
    ui->label_Server->setVisible(false);
    ui->label_Users->setVisible(false);
    ui->label_Settings->setVisible(false);


    connect(ui->ReductUI_Button ,SIGNAL(clicked()),this,SLOT(OnMinimizeUIBtn()));
    connect(ui->ExtendUI_Button ,SIGNAL(clicked()),this,SLOT(OnMaximizeUIBtn()));
    connect(ui->Menu_Button, SIGNAL(clicked()),this,SLOT(ShowMenu()));
    connect(ui->ShowMenu_Button, SIGNAL(clicked()),this,SLOT(onBackToMenu()));
    connect(ui->Profile_Button, SIGNAL(clicked()),this,SLOT(onProfilBtn()));
    connect(timer,SIGNAL(timeout()),this,SLOT(setTime())); timer->start(1000);


    labelWidth=ui->label_IconeApp->width(); labelHeight=ui->label_IconeApp->height();
    QPixmap pix(":/img/Images/logo-req.png");
    ui->label_IconeApp->setPixmap(pix.scaled(labelWidth,labelHeight,Qt::KeepAspectRatio));
    setWindowTitle("Administrator Ui [*]"); setWindowModified(true);
    statusWindows=0; isMenuFrameShow=false; isMenuShow=false; onBackToMenu();
    setAnimationInScrollArea();
}



void adminUI::hideMenu(int timer){
    BtnWidth=144; BtnHeight=90;
                    //Home
    animation=new QPropertyAnimation(ui->home_Button,"geometry");
    animation->setDuration(timer);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(1,20,BtnWidth,BtnHeight));
    animation->setEndValue(QRectF(80,70,0,0));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animationLabel=new QPropertyAnimation(ui->label_Home,"geometry");
    animationLabel->setDuration(timer);
    animationLabel->setEasingCurve(QEasingCurve::Linear);
    animationLabel->setStartValue(QRectF(1,99,144,20));
    animationLabel->setEndValue(QRectF(1,99,0,20));
    animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                    //Server
    animation=new QPropertyAnimation(ui->server_Button,"geometry");
    animation->setDuration(timer);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(1,20,BtnWidth,BtnHeight));
    animation->setEndValue(QRectF(80,70,0,0));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animationLabel=new QPropertyAnimation(ui->label_Server,"geometry");
    animationLabel->setDuration(timer);
    animationLabel->setEasingCurve(QEasingCurve::Linear);
    animationLabel->setStartValue(QRectF(1,99,144,20));
    animationLabel->setEndValue(QRectF(1,99,0,20));
    animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                    //UserManagement
    animation=new QPropertyAnimation(ui->userManagement_Button,"geometry");
    animation->setDuration(timer);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(1,20,BtnWidth,BtnHeight));
    animation->setEndValue(QRectF(80,70,0,0));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animationLabel=new QPropertyAnimation(ui->label_Users,"geometry");
    animationLabel->setDuration(timer);
    animationLabel->setEasingCurve(QEasingCurve::Linear);
    animationLabel->setStartValue(QRectF(1,99,144,20));
    animationLabel->setEndValue(QRectF(1,99,0,20));
    animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                        //Settings
    animation=new QPropertyAnimation(ui->leaves_Button,"geometry");
    animation->setDuration(timer);
    animation->setEasingCurve(QEasingCurve::Linear);
    animation->setStartValue(QRectF(1,20,BtnWidth,BtnHeight));
    animation->setEndValue(QRectF(80,70,0,0));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animationLabel=new QPropertyAnimation(ui->label_Settings,"geometry");
    animationLabel->setDuration(timer);
    animationLabel->setEasingCurve(QEasingCurve::Linear);
    animationLabel->setStartValue(QRectF(1,99,144,20));
    animationLabel->setEndValue(QRectF(1,99,0,20));
    animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                  //closeFrameAutomaticly
    animationLabel=new QPropertyAnimation(ui->Contenu_frame,"geometry");
    animationLabel->setDuration(700);
    animationLabel->setEasingCurve(QEasingCurve::Linear);
    animationLabel->setStartValue(QRectF(151,1,1850,1000));
    animationLabel->setEndValue(QRectF(0,1,2000,1000));
    animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
    isMenuFrameShow=false;

}

void adminUI::setDate(){
   QString data_text=QDate::currentDate().toString(Qt::DateFormat::DefaultLocaleLongDate);
   ui->label_Date->setText(data_text);

}

void adminUI::setAnimationInScrollArea()
{
    int BtnWidth_=80;
    int BtnHeight_=60;

    animation=new QPropertyAnimation(ui->DisconectFromServer_Button,"geometry");
    animation->setDuration(500);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(0,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(510,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animation=new QPropertyAnimation(ui->ConnectToServer_Button,"geometry");
    animation->setDuration(750);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(0,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(410,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animation=new QPropertyAnimation(ui->logFile_Button,"geometry");
    animation->setDuration(1000);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(0,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(310,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animation=new QPropertyAnimation(ui->Calendar_Button,"geometry");
    animation->setDuration(1250);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(0,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(210,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animation=new QPropertyAnimation(ui->Broadcast_Button,"geometry");
    animation->setDuration(1500);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(520,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(110,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

    animation=new QPropertyAnimation(ui->File_Button,"geometry");
    animation->setDuration(1700);
    animation->setEasingCurve(QEasingCurve::InQuart);
    animation->setStartValue(QRectF(510,0,BtnWidth_,BtnHeight_));
    animation->setEndValue(QRectF(10,0,BtnWidth_,BtnHeight_));
    animation->start(QAbstractAnimation::DeleteWhenStopped);

}

void adminUI::MethodeOfMaxAndMinFrame(){

    if(isMenuFrameShow){
        animationLabel=new QPropertyAnimation(ui->Contenu_frame,"geometry");
        animationLabel->setDuration(1);
        animationLabel->setEasingCurve(QEasingCurve::Linear);
        animationLabel->setStartValue(QRectF(0,1,2000,1000));
        animationLabel->setEndValue(QRectF(150,1,1850,1000));
        animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
        isMenuFrameShow=true;
    }
    else{
        animationLabel=new QPropertyAnimation(ui->Contenu_frame,"geometry");
        animationLabel->setDuration(1);
        animationLabel->setEasingCurve(QEasingCurve::Linear);
        animationLabel->setStartValue(QRectF(150,1,1850,1000));
        animationLabel->setEndValue(QRectF(0,1,2000,1000));
        animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
        isMenuFrameShow=false;
    }
}

void adminUI::VisibleMenu(){
     BtnWidth=144;
     BtnHeight=90;
     int timer=600;

                //Home
     animation=new QPropertyAnimation(ui->home_Button,"geometry");
     animation->setDuration(timer);
     animation->setEasingCurve(QEasingCurve::Linear);
     animation->setStartValue(QRectF(80,70,0,0));
     animation->setEndValue(QRectF(1,20,BtnWidth,BtnHeight));
     animation->start(QAbstractAnimation::DeleteWhenStopped);
     ui->home_Button->setVisible(true);

     ui->label_Home->setVisible(true);
     animationLabel=new QPropertyAnimation(ui->label_Home,"geometry");
     animationLabel->setDuration(750);
     animationLabel->setEasingCurve(QEasingCurve::Linear);
     animationLabel->setStartValue(QRectF(1,99,0,20));
     animationLabel->setEndValue(QRectF(1,99,144,20));
     animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                    //Server
     ui->server_Button->setVisible(true);
     animation=new QPropertyAnimation(ui->server_Button,"geometry");
     animation->setDuration(800);
     animation->setEasingCurve(QEasingCurve::Linear);
     animation->setStartValue(QRectF(80,70,0,0));
     animation->setEndValue(QRectF(1,20,BtnWidth,BtnHeight));
     animation->start(QAbstractAnimation::DeleteWhenStopped);

     ui->label_Server->setVisible(true);
     animationLabel=new QPropertyAnimation(ui->label_Server,"geometry");
     animationLabel->setDuration(850);
     animationLabel->setEasingCurve(QEasingCurve::Linear);
     animationLabel->setStartValue(QRectF(1,99,0,20));
     animationLabel->setEndValue(QRectF(1,99,144,20));
     animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                //UserManagement
     ui->userManagement_Button->setVisible(true);
     animation=new QPropertyAnimation(ui->userManagement_Button,"geometry");
     animation->setDuration(1000);
     animation->setEasingCurve(QEasingCurve::Linear);
     animation->setStartValue(QRectF(80,70,0,0));
     animation->setEndValue(QRectF(1,20,BtnWidth,BtnHeight));
     animation->start(QAbstractAnimation::DeleteWhenStopped);

     ui->label_Users->setVisible(true);
     animationLabel=new QPropertyAnimation(ui->label_Users,"geometry");
     animationLabel->setDuration(950);
     animationLabel->setEasingCurve(QEasingCurve::Linear);
     animationLabel->setStartValue(QRectF(1,99,0,20));
     animationLabel->setEndValue(QRectF(1,99,144,20));
     animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
                    //Settings
     ui->leaves_Button->setVisible(true);
     animation=new QPropertyAnimation(ui->leaves_Button,"geometry");
     animation->setDuration(1200);
     animation->setEasingCurve(QEasingCurve::Linear);
     animation->setStartValue(QRectF(80,70,0,0));
     animation->setEndValue(QRectF(1,20,BtnWidth,BtnHeight));
     animation->start(QAbstractAnimation::DeleteWhenStopped);

     ui->label_Settings->setVisible(true);
     animationLabel=new QPropertyAnimation(ui->label_Settings,"geometry");
     animationLabel->setDuration(1050);
     animationLabel->setEasingCurve(QEasingCurve::Linear);
     animationLabel->setStartValue(QRectF(1,99,0,20));
     animationLabel->setEndValue(QRectF(1,99,144,20));
     animationLabel->start(QAbstractAnimation::DeleteWhenStopped);

}

adminUI::~adminUI(){
    delete ui;
}

void adminUI::OnCloseUIBtn(){
   if(windowShouldClose()){
        this->close();
   }
}

void adminUI::OnMinimizeUIBtn(){
    this->showMinimized();
}

void adminUI::OnMaximizeUIBtn(){

    if(statusWindows==0){
        MethodeOfMaxAndMinFrame();
        this->showMaximized();
        ui->ExtendUI_Button->setIcon(QIcon(":/img/Images/restore_down_48px.png"));
        statusWindows=1;
     }
    else{

        MethodeOfMaxAndMinFrame();
        this->showNormal();
        ui->ExtendUI_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
        statusWindows=0;
    }
}

void adminUI::ShowMenu(){

    if(!isMenuShow) {
      VisibleMenu();
      isMenuShow=true;
    }
    else{
        hideMenu(800);
        isMenuShow=false;
    }
}

void adminUI::onBackToMenu(){

    if(isMenuFrameShow){
        if(isMenuShow){
            hideMenu(100);
            isMenuShow=false;
        }
        animationLabel=new QPropertyAnimation(ui->Contenu_frame,"geometry");
        animationLabel->setDuration(700);
        animationLabel->setEasingCurve(QEasingCurve::Linear);
        animationLabel->setStartValue(QRectF(151,1,1850,1000));
        animationLabel->setEndValue(QRectF(0,1,2000,1000));
        animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
        isMenuFrameShow=false;
    }
    else{
            if(!isMenuShow){
               hideMenu(00);
               isMenuShow=false;
            }
        animationLabel=new QPropertyAnimation(ui->Contenu_frame,"geometry");
        animationLabel->setDuration(700);
        animationLabel->setEasingCurve(QEasingCurve::Linear);
        animationLabel->setStartValue(QRectF(0,1,2000,1000));
        animationLabel->setEndValue(QRectF(151,1,1850,1000));
        animationLabel->start(QAbstractAnimation::DeleteWhenStopped);
        isMenuFrameShow=true;
    }
}

void adminUI::setTime(){
   time = QTime::currentTime();
   time_Text=time.toString(Qt::DateFormat::DefaultLocaleShortDate);
   ui->label_Heure->setText(time_Text);
}

void adminUI::onProfilBtn(){

     profilUi=new ProfileUI(this);
     profilUi->show();

     animation = new QPropertyAnimation(profilUi, "geometry");
     animation->setDuration(400);
     animation->setEasingCurve(QEasingCurve::Linear);
     animation->setStartValue(QRectF(1100,0,profilUi->width(),profilUi->height()));
     animation->setEndValue(QRectF(1085,120,profilUi->width(),profilUi->height()));
     animation->start();


}

void adminUI::OnServerBtn(){
    if(!isServerShow){
      server_Ui=new ServerUi(this);
      server_Ui->show();
      animation = new QPropertyAnimation(server_Ui, "geometry");
      animation->setDuration(400);
      animation->setEasingCurve(QEasingCurve::Linear);
      animation->setStartValue(QRectF(600,0,server_Ui->width(),server_Ui->height()));
      animation->setEndValue(QRectF(600,320,server_Ui->width(),server_Ui->height()));
      animation->start();
      isServerShow=true;
    }

}



void adminUI::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        MouseOff=true;
    }
}

void adminUI::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
      MouseOff=false;
    }
}

void adminUI::mouseMoveEvent(QMouseEvent *event){
    if(MouseOff){
      mousePoint=event->globalPos();
      move(mousePoint);
    }
}

bool adminUI::windowShouldClose(){
    if(!isWindowModified()){
        return true;
    }
        QMessageBox::StandardButton answer=QMessageBox::question(this,tr("Close window"),
                                                                 tr("really close window ?"),
                                                                 QMessageBox::Yes | QMessageBox::No);
        return (answer==QMessageBox::Yes);
}
