#include "setConges.h"
#include "ui_setConges.h"

setConges::setConges(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::setConges)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    mouseOff=false;
    connect(ui->close_Button, SIGNAL(clicked()),this,SLOT(close()));
}

setConges::setConges(QObject *controller):
    ui(new Ui::setConges)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    mouseOff=false;
    connect(ui->close_Button, SIGNAL(clicked()),controller,SLOT(CloseSetCngeUI()));
    connect(ui->definePeriod_Button, SIGNAL(clicked()),controller,SLOT(setPeriodAndDuration()));

}


void setConges::setBeginDate(QDate dateEdit){
    ui->BeginDate_dateEdit->setDate(dateEdit);
}

void setConges::setDuration(quint8 duration){
     ui->Duration_spinBox->setValue(duration);
}

void setConges::setEndDate(QDate dateEdit){
    ui->EndDate_dateEdit->setDate(dateEdit);
}

QDate setConges::getBeginDate() const{
    return ui->BeginDate_dateEdit->date();
}

QDate setConges::getEndDate() const{
    return ui->EndDate_dateEdit->date();
}

quint8 setConges::getDuration() const{
    if(ui->Duration_spinBox->value()==0){
        throw userExceptions("La durée doit être supérieure à 0, veuillez saisir une valeur correcte.");
    }
   return ui->Duration_spinBox->value();
}

setConges::~setConges(){
    delete ui;
}

void setConges::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        mouseOff=true;
    }

}

void setConges::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
       mouseOff=false;
    }
}

void setConges::mouseMoveEvent(QMouseEvent *event){
      mousePoint=event->globalPos();
      move(mousePoint);
}
