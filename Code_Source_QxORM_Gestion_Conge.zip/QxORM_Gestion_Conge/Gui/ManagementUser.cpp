#include "ManagementUser.h"
#include "ui_ManagementUser.h"
#include <QTableWidgetItem>


ManagementUser::ManagementUser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagementUser)
{

    ui->setupUi(this);
    Initialise();


   connect(ui->m_expand_Button,SIGNAL(clicked()), this,SLOT(maximizeWidget()));
    connect(ui->m_radius_Button,SIGNAL(clicked()), this,SLOT(minimizeWidget()));
    connect(ui->chevron_Button,SIGNAL(clicked()), this,SLOT(onChevronButton()));

    connect(ui->m_close_Button,SIGNAL(clicked()),this,SLOT(close()));
    statusWindows=0; showframeOfTopMenus=false;
}


ManagementUser::ManagementUser(QObject *mngmntUserCntrller):
    ui(new Ui::ManagementUser)
{
    ui->setupUi(this);
    Initialise();

    connect(ui->m_close_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(closeMngUserUi()));
    connect(ui->addUser_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(runAddUser()));

    connect(ui->TableAdmin_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(onTableAdminBtn()));
    connect(ui->TableProfessionnel_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(onTableProfessionnelBtn()));
    connect(ui->TableEmploye_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(onTableEmployeBtn()));
    connect(ui->TableManager_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(onTableManagerBtn()));
    connect(ui->TableDRH_Button,SIGNAL(clicked()),mngmntUserCntrller,SLOT(onTableDrhBtn()));

    connect(this->AjouterUser,SIGNAL(triggered()),mngmntUserCntrller,SLOT(runAddUser()));
    statusWindows=0; showframeOfTopMenus=false;


}

QStackedWidget * ManagementUser::getStackedWidget(){
    return ui->stackedWidget;
}




void ManagementUser::Initialise()
{
    this->setWindowFlags(Qt::Widget | Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    mouseOff=false;

    labelWidth=ui->label_IconeApp->width(); labelHeight=ui->label_IconeApp->height();
    QPixmap pix(":/img/Images/logo-req.png");
    ui->label_IconeApp->setPixmap(pix.scaled(labelWidth,labelHeight,Qt::KeepAspectRatio));

    ui->m_close_Button->setIcon(QIcon(":/img/Images/cancel_60px.png"));
    ui->m_expand_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
    ui->m_radius_Button->setIcon(QIcon(":/img/Images/minimize_window_48px.png"));
    ui->chevron_Button->setIcon(QIcon(":/img/Images/chevron_down_48px.png"));
    ui->TableProfessionnel_Button->setIcon(QIcon(":/img/Images/tableBlue_96px.png"));
    ui->TableEmploye_Button->setIcon(QIcon(":/img/Images/tableBlue_96px.png"));
    ui->TableManager_Button->setIcon(QIcon(":/img/Images/tableBlue_96px.png"));
    ui->TableAdmin_Button->setIcon(QIcon(":/img/Images/tableBlue_96px.png"));
    ui->TableDRH_Button->setIcon(QIcon(":/img/Images/tableBlue_96px.png"));
    ui->EditEmploye_Button->setIcon(QIcon(":/img/Images/registrationEmp_96px.png"));
    ui->addUser_Button->setIcon(QIcon(":/img/Images/add_male_user_128px.png"));
    ui->EditManager_Button->setIcon(QIcon(":/img/Images/registrationM_80px.png"));
    ui->Delete_Button->setIcon(QIcon(":/img/Images/delete_user_male_48px.png"));
    ui->EditDRH_Button->setIcon(QIcon(":/img/Images/school_director_96px.png"));
    ui->EditCongesTaken_Button->setIcon(QIcon(":/img/Images/ok_96px.png"));
    ui->EditCongesTaken_Button->setIcon(QIcon(":/img/Images/edit_80px.png"));
    ui->DeleteCngesTaken_Button->setIcon(QIcon(":/img/Images/trash_can_96px.png"));
    ui->EditRequest_Button->setIcon(QIcon(":/img/Images/edit_pie_chart_report_96px.png"));
    ui->DeleteRequest_Button->setIcon(QIcon(":/img/Images/delete_pie_chart_report_96px.png"));

    ui->tableWidget_Professionel->setColumnWidth(0,75);
    ui->tableWidget_Professionel->setColumnWidth(1,200);
    ui->tableWidget_Professionel->setColumnWidth(2,200);
    ui->tableWidget_Professionel->setColumnWidth(3,160);
    ui->tableWidget_Professionel->setColumnWidth(4,120);
    ui->tableWidget_Professionel->setColumnWidth(5,250);
    ui->tableWidget_Professionel->setColumnWidth(6,250);
    ui->tableWidget_Professionel->setColumnWidth(7,170);
    ui->tableWidget_Professionel->setColumnWidth(8,170);
    ui->tableWidget_Professionel->setColumnWidth(9,170);
    ui->tableWidget_Professionel->setColumnWidth(10,170);
    ui->tableWidget_Professionel->setColumnWidth(11,170);
    ui->tableWidget_Professionel->setColumnWidth(12,300);
    ui->tableWidget_Professionel->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_Employe->setColumnWidth(0,75);
    ui->tableWidget_Employe->setColumnWidth(1,200);
    ui->tableWidget_Employe->setColumnWidth(2,200);
    ui->tableWidget_Employe->setColumnWidth(3,160);
    ui->tableWidget_Employe->setColumnWidth(4,120);
    ui->tableWidget_Employe->setColumnWidth(5,250);
    ui->tableWidget_Employe->setColumnWidth(6,250);
    ui->tableWidget_Employe->setColumnWidth(7,170);
    ui->tableWidget_Employe->setColumnWidth(8,170);
    ui->tableWidget_Employe->setColumnWidth(9,170);
    ui->tableWidget_Employe->setColumnWidth(10,170);
    ui->tableWidget_Employe->setColumnWidth(11,170);
    ui->tableWidget_Employe->setColumnWidth(12,200);
    ui->tableWidget_Employe->setColumnWidth(13,150);
    ui->tableWidget_Employe->setColumnWidth(14,75);
    ui->tableWidget_Employe->setColumnWidth(15,190);
    ui->tableWidget_Employe->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_Manager->setColumnWidth(0,75);
    ui->tableWidget_Manager->setColumnWidth(1,200);
    ui->tableWidget_Manager->setColumnWidth(2,200);
    ui->tableWidget_Manager->setColumnWidth(3,160);
    ui->tableWidget_Manager->setColumnWidth(4,120);
    ui->tableWidget_Manager->setColumnWidth(5,250);
    ui->tableWidget_Manager->setColumnWidth(6,250);
    ui->tableWidget_Manager->setColumnWidth(7,170);
    ui->tableWidget_Manager->setColumnWidth(8,170);
    ui->tableWidget_Manager->setColumnWidth(9,170);
    ui->tableWidget_Manager->setColumnWidth(10,170);
    ui->tableWidget_Manager->setColumnWidth(11,170);
    ui->tableWidget_Manager->setColumnWidth(12,300);
    ui->tableWidget_Manager->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_DRH->setColumnWidth(0,75);
    ui->tableWidget_DRH->setColumnWidth(1,200);
    ui->tableWidget_DRH->setColumnWidth(2,200);
    ui->tableWidget_DRH->setColumnWidth(3,160);
    ui->tableWidget_DRH->setColumnWidth(4,120);
    ui->tableWidget_DRH->setColumnWidth(5,250);
    ui->tableWidget_DRH->setColumnWidth(6,250);
    ui->tableWidget_DRH->setColumnWidth(7,170);
    ui->tableWidget_DRH->setColumnWidth(8,170);
    ui->tableWidget_DRH->setColumnWidth(9,170);
    ui->tableWidget_DRH->setColumnWidth(10,170);
    ui->tableWidget_DRH->setColumnWidth(11,170);
    ui->tableWidget_DRH->setColumnWidth(12,300);
    ui->tableWidget_DRH->setContextMenuPolicy(Qt::ActionsContextMenu);

    ui->tableWidget_Administrator->setColumnWidth(0,75);
    ui->tableWidget_Administrator->setColumnWidth(1,200);
    ui->tableWidget_Administrator->setColumnWidth(2,200);
    ui->tableWidget_Administrator->setColumnWidth(3,160);
    ui->tableWidget_Administrator->setColumnWidth(4,120);
    ui->tableWidget_Administrator->setColumnWidth(5,250);
    ui->tableWidget_Administrator->setColumnWidth(6,250);
    ui->tableWidget_Administrator->setColumnWidth(7,170);
    ui->tableWidget_Administrator->setColumnWidth(8,170);
    ui->tableWidget_Administrator->setColumnWidth(9,170);
    ui->tableWidget_Administrator->setColumnWidth(10,170);
    ui->tableWidget_Administrator->setColumnWidth(11,170);
    ui->tableWidget_Administrator->setColumnWidth(12,300);
    ui->tableWidget_Administrator->setContextMenuPolicy(Qt::ActionsContextMenu);


    //Context Menu
    modifier= new QAction("Modifier utilisateur");
    supprimer= new QAction("Supprimer utilisateur");
    AjouterUser= new QAction("Creer utilisateur");
    modifierCngesEmploye= new QAction("Modifier Congés");

    modifier->setIcon(QIcon(":/img/Images/editNew_96px.png"));
    supprimer->setIcon(QIcon(":/img/Images/delete_trash2_96px.png"));
    AjouterUser->setIcon(QIcon(":/img/Images/add_male_user_128px.png"));
    modifierCngesEmploye->setIcon(QIcon(":/img/Images/leave_96px.png"));

    liste_ActionUser.append(AjouterUser);
    liste_ActionUser.append(modifier);
    liste_ActionUser.append(supprimer);

    ui->tableWidget_Employe->addActions(liste_ActionUser);
    ui->tableWidget_Employe->addAction(modifierCngesEmploye);
    ui->tableWidget_Manager->addActions(liste_ActionUser);
    ui->tableWidget_DRH->addActions(liste_ActionUser);
    ui->tableWidget_Administrator->addActions(liste_ActionUser);

    connect(ui->m_expand_Button,SIGNAL(clicked()), this,SLOT(maximizeWidget()));
    connect(ui->m_radius_Button,SIGNAL(clicked()), this,SLOT(minimizeWidget()));
    connect(ui->chevron_Button,SIGNAL(clicked()), this,SLOT(onChevronButton()));


    //connect(ui->tableWidget_Professionel,SIGNAL(itemDoubleClicked(QTableWidgetItem*)),
           // this,SLOT(onChevronButton()));

}

ManagementUser::~ManagementUser(){
    delete ui;
}

void ManagementUser::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        mouseOff=true;
    }
}

void ManagementUser::mouseReleaseEvent(QMouseEvent *event){
    if(event->Close){
      mouseOff=false;
    }
}

void ManagementUser::mouseMoveEvent(QMouseEvent *event){
    if(mouseOff){
        mousePoint=event->globalPos();
        move(mousePoint);
    }
}

void ManagementUser::maximizeWidget(){
    if(statusWindows==0){
        this->showMaximized();
        ui->m_expand_Button->setIcon(QIcon(":/img/Images/restore_down_48px.png"));
        statusWindows=1;
     }
    else{
        this->showNormal();
        ui->m_expand_Button->setIcon(QIcon(":/img/Images/maximize_button_48px.png"));
        statusWindows=0;
    }
}

void ManagementUser::minimizeWidget(){
    this->showMinimized();
}

void ManagementUser::onChevronButton(){
    if(showframeOfTopMenus){
        animation=new QPropertyAnimation(ui->frameTopMenu,"maximumHeight");
        animation->setDuration(300);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(175);
        animation->setEndValue(0);
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        showframeOfTopMenus=false;
        ui->chevron_Button->setIcon(QIcon(":/img/Images/chevron_down_48px.png"));
    }
    else{
        animation=new QPropertyAnimation(ui->frameTopMenu,"maximumHeight");
        animation->setDuration(300);
        animation->setEasingCurve(QEasingCurve::Linear);
        animation->setStartValue(0);
        animation->setEndValue(175);
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        showframeOfTopMenus=true;
        ui->chevron_Button->setIcon(QIcon(":/img/Images/chevron_up_48px.png"));
    }

}





