#ifndef SERVERUI_H
#define SERVERUI_H

#include <QWidget>
#include <QProcess>
#include <QSystemTrayIcon>
#include <QPoint>
#include <QMouseEvent>

namespace Ui {
class ServerUi;
}

class ServerUi : public QWidget
{
    Q_OBJECT

public:
    explicit ServerUi(QWidget *parent = nullptr);
    explicit ServerUi(QObject *Controller);
    void initialise();
    QProcess * getProcess() { return &server_Process;}
    QSystemTrayIcon *getQSystemTrayIcon() const {return notif_System;}

    ~ServerUi();

private slots:
    void onMinimizeBtn();

protected:
    QPoint MousePoint;
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent *event);

private:
    Ui::ServerUi *ui;
    QProcess server_Process;
    QSystemTrayIcon * notif_System;
    bool mouseOff;
};

#endif // SERVERUI_H
