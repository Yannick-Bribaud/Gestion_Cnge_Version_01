#ifndef SETCONGES_H
#define SETCONGES_H

#include <QWidget>
#include <QMouseEvent>
#include <QDateEdit>
#include "Exceptions/UserExceptions/userExceptions.h"
#include "Gui/box.h"

namespace Ui {
class setConges;
}

class setConges : public QWidget
{
    Q_OBJECT

public:
    explicit setConges(QWidget *parent = nullptr);
    explicit setConges(QObject * controller);
    void setBeginDate(QDate dateEdit);
    void setDuration(quint8 duration);
    void setEndDate(QDate dateEdit);
    QDate getBeginDate() const;
    QDate getEndDate() const;
    quint8 getDuration() const;
    ~setConges();


protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent *event);

private:
    Ui::setConges *ui;
    bool mouseOff;
    Box * MessageBox;
};

#endif // SETCONGES_H
