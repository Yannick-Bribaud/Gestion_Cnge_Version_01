#ifndef MANAGEMENTUSER_H
#define MANAGEMENTUSER_H

#include <QWidget>
#include <QMouseEvent>
#include <QPropertyAnimation>
#include <QAction>
#include "Gui/AddUserUi.h"
#include <QStackedWidget>


namespace Ui {
class ManagementUser;
}

class ManagementUser : public QWidget
{
    Q_OBJECT

public:
    explicit ManagementUser(QWidget *parent = nullptr);
    explicit ManagementUser(QObject * mngmntUserCntrller);
    QStackedWidget * getStackedWidget();
    void Initialise();

    ~ManagementUser();

protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent * event);

private slots:
    void maximizeWidget();
    void minimizeWidget();
    void onChevronButton();

private:
    Ui::ManagementUser *ui;
    QPropertyAnimation * animation;
    AddUserUi * addUser;
    QAction * modifier;
    QAction * supprimer;
    QAction * AjouterUser;
    QAction * modifierCngesEmploye;
    QList<QAction *>liste_ActionUser;


    bool mouseOff;
    int labelWidth;
    int labelHeight;
    int statusWindows;
    bool showframeOfTopMenus;
    bool showframeOfVerticalMenus;

};

#endif // MANAGEMENTUSER_H
