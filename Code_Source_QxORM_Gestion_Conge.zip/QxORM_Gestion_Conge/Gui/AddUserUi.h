#ifndef ADDUSERUI_H
#define ADDUSERUI_H

#include <QWidget>
#include <QMouseEvent>
#include <Gui/setConges.h>
#include "Entites/genre.h"
#include "Entites/status.h"


namespace Ui {
class AddUserUi;
}

class AddUserUi : public QWidget
{
    Q_OBJECT

public:
    explicit AddUserUi(QWidget *parent = nullptr);
    explicit AddUserUi(QObject * addUserController);

    void setRadioBtnCheckedEmploye();
    void setRadioBtnCheckedManager();
    void setRadioBtnCheckedAdmin();
    void setRadioBtnCheckedDRH();

    bool getIsCheckedRadioBtnEmploye();
    bool getIsCheckedRadioBtnManager();
    bool getIsCheckedRadioBtnAdmin();
    bool getIsCheckedRadioBtnDRH();

    bool getIsCheckedRadioBtnHomme();
    bool getIsCheckedRadioBtnFemme();
    bool getIsCheckedRadioBtnInconnu();


    //Personnel Information

    QString getEditNom();
    QString getEditPrenom();
    QDate getEditDateNaissance();
    Genre::EnumGenre getEditGenre();
    QString getEditAdresse();
    QString getEditTelephone();

    //Profession Information
      QString getEditMatricule();
      QString getEditLogin();
      QString getEditProfession();
      QString getEditPassword();
      QString getEditEmail();
      Status::EnumStatus getEditStatus();

    ~AddUserUi();

protected:
    QPoint mousePoint;
    void mousePressEvent(QMouseEvent * event);
    void mouseReleaseEvent(QMouseEvent * event);
    void mouseMoveEvent(QMouseEvent * event);

private:
    Ui::AddUserUi * ui;
    bool MouseOff;
    setConges * setCnges;
};

#endif // ADDUSERUI_H
