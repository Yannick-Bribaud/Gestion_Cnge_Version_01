#ifndef PROFILEUI_H
#define PROFILEUI_H

#include <QWidget>
#include <QPropertyAnimation>

namespace Ui {
class ProfileUI;
}

class ProfileUI : public QWidget
{
    Q_OBJECT

public:
    explicit ProfileUI(QWidget *parent = nullptr);
    //explicit ProfileUI(QObject * user, QWidget *parent = nullptr);
    void animationWidgetProfil();

    ~ProfileUI();

private:
    Ui::ProfileUI *ui;
    QPropertyAnimation * animation;
    QPropertyAnimation * animationLabel;
};

#endif // PROFILEUI_H
