#include "qxdbconnect.h"

QxdbConnect * QxdbConnect::QxdbConnected=NULL;
QxdbConnect *QxdbConnect::getInstance(){

    if(QxdbConnected==NULL){
        QxdbConnected=new QxdbConnect();
    }
    return QxdbConnected;
}

void QxdbConnect::detruireInstance(){
    if(QxdbConnected!=NULL){
      QxdbConnected=NULL;
    }
}

bool QxdbConnect::isConnected(){
   return db.isOpen();
}

bool QxdbConnect::Qxconnecting(const QString & driver, const QString &dataBaseName, const QString &username, const QString &password, const QString &adrServer) noexcept(false)
{
    if(driver!="QMYSQL"){
       throw dbError(db.lastError().text());
    }
     QMutexLocker verrou(&mutex);

        if(!db.isOpen()){

         QxSqlDatabase::getSingleton()->setDriverName(driver);
         QxSqlDatabase::getSingleton()->setDatabaseName(dataBaseName);
         QxSqlDatabase::getSingleton()->setUserName(username);
         QxSqlDatabase::getSingleton()->setPassword(password);
         QxSqlDatabase::getSingleton()->setHostName(adrServer);

         db=QxSqlDatabase::getDatabase();

        if(db.isOpen()){
          return true;
        }
        else{
           throw dbError(QSqlError::ErrorType::ConnectionError);
        }
     }
     else return true;
}

bool QxdbConnect::OpenDataBase(){
    return db.open();
}

void QxdbConnect::closeDataBase(){
     return db.close();
}

QxdbConnect::QxdbConnect(){
  Qxconnecting("QMYSQL","qxorm","root","","localhost");
}

