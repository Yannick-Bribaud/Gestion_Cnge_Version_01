#ifndef QXDBCONNECT_H
#define QXDBCONNECT_H

#include <QException>
#include "Exceptions/dbExceptions/dberror.h"
#include <QxDao/QxSqlDatabase.h>
using namespace qx;

class QxdbConnect : public QException, public QSqlDatabase
{
public:
   static QxdbConnect * getInstance();
   static void detruireInstance();
   bool isConnected();
   bool Qxconnecting(const QString & driver,const QString & dataBaseName, const QString & username, const QString & password, const QString & adrServer) noexcept(false) ;
   bool OpenDataBase();
   void closeDataBase();

private:
    QxdbConnect();
    static QxdbConnect * QxdbConnected;
    QSqlDatabase db;
    QMutex mutex;
};

#endif // QXDBCONNECT_H
