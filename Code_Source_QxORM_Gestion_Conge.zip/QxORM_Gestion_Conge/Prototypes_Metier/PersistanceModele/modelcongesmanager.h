#ifndef MODELCONGESMANAGER_H
#define MODELCONGESMANAGER_H

#include "Entites/manager.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesemploye.h"

class ModelCongesEmploye;

class _QX_DLL_EXPORT_GESTION_CONGES ModelCongesManager : public Managers
{
    QX_REGISTER_FRIEND_CLASS(ModelCongesManager)

public:
   typedef qx::QxCollection<long, std::shared_ptr<ModelCongesEmploye>>list_of_ModelCongesEmploye;

    ModelCongesManager(){};
    ModelCongesManager(const QString & matricule, const QString & nom, const QString & prenom,const Genre::EnumGenre genre,const QString & email,const QString & telephone)
        { setMatricule(matricule) ; setNom(nom); setPrenom(prenom); setEmail(email); setGenre(genre); setTelephone(telephone); }

    ModelCongesManager(const QString & matricule, const QString & nom, const QString & prenom,const Genre::EnumGenre genre,const QString & email,const QString & telephone,const list_of_ModelCongesEmploye & EmployeList)
                      :m_list_of_ModelCongesEmploye(EmployeList){ setMatricule(matricule); setNom(nom); setPrenom(prenom); setEmail(email); setGenre(genre); setTelephone(telephone);}
    virtual ~ModelCongesManager(){};


    //setter & getters
    list_of_ModelCongesEmploye getlist_of_ModelCongesEmploye() const { return m_list_of_ModelCongesEmploye; }
    void setlist_of_ModelCongesEmploye(const list_of_ModelCongesEmploye & myEmployelist) { m_list_of_ModelCongesEmploye=myEmployelist; }

    void setMatriculeModelMng(const QString & matricule) { pro_matricule=matricule; }
    void setNomModelMng(const QString & nom) { p_nom=nom; }
    void setPrenomModelMng(const QString & prenom) {p_prenom = prenom; }
    void setEmailModelMng(const QString & email) {pro_email = email; }

    QString getMatriculeModelMng() const {return pro_matricule;}
    QString getNomModelMng() const {return p_nom;}
    QString getPrenoModelMngm() const {return  p_prenom; }


protected:
   list_of_ModelCongesEmploye m_list_of_ModelCongesEmploye;

private:

};

QX_REGISTER_HPP_ENTITY(ModelCongesManager,Personne,0)

typedef std::shared_ptr<ModelCongesManager>modelCongesManagers_ptr;
typedef qx::QxCollection<long, modelCongesManagers_ptr> list_of_modelManagers_ptr;
typedef QList<ModelCongesManager> list_of_modelManagers;
typedef qx::QxCollection<long, std::shared_ptr<ModelCongesEmploye>>list_of_ModelCongesEmploye;

#endif // MODELCONGESMANAGER_H
