#include "Precompilation/precompilation.h"
#include "validationconges.h"
#include <QxOrm_Impl.h>


QX_REGISTER_CPP_ENTITY(ValidationConges)

namespace qx{

template <> void register_class(QxClass<ValidationConges> &ValiCng){

       ValiCng.setName("t_validationcnges");
       ValiCng.data(&ValidationConges::idDemande,"idDemande");

    }
}
