#ifndef MODELCONGESEMPLOYE_H
#define MODELCONGESEMPLOYE_H
#include "Entites/employe.h"
#include "Entites/personne.h"
#include "Entites/manager.h"
#include "Entites/demande.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesmanager.h"
#include "Prototypes_Metier/PersistanceModele/congesforemploye.h"


class ModelCongesManager;
class CongesForEmploye;
class Demande;

class _QX_DLL_EXPORT_GESTION_CONGES ModelCongesEmploye : public Employe
{
    QX_REGISTER_FRIEND_CLASS(ModelCongesEmploye)

public:
     typedef std::shared_ptr<ModelCongesManager>modelmanagr_ptr;
     typedef qx::QxCollection<long, std::shared_ptr<CongesForEmploye>>list_of_CongesEmploye;
     typedef qx::QxCollection<long, std::shared_ptr<Demande>>list_of_demandes;

    void methodeAbstraite() override {};
    ModelCongesEmploye(){};
    ModelCongesEmploye(QDate debutPeriode,QDate finPeriode, qint8 soldeConge,QString nom, QString prenom, Genre::EnumGenre genre, QDate dateN, QString adresse, QString telephone,
                       QString matricule,QString profession, Status::EnumStatus status, QString login, QString password,QString email,modelmanagr_ptr manager)
                       :Employe(debutPeriode,finPeriode,soldeConge,nom,prenom,genre,dateN,adresse,telephone,matricule,profession,status,login,password,email){ setManager(manager);}
    ModelCongesEmploye(const QString & matricule, const QString & nom, const QString & prenom,const Genre::EnumGenre genre,const QString & email,const QString & telephone,modelmanagr_ptr manager)
                      { setMatricule(matricule); setNom(nom); setPrenom(prenom); setGenre(genre); setEmail(email); setTelephone(telephone); setManager(manager);}
    ModelCongesEmploye(const QString & matricule, const QString & nom, const QString & prenom,const Genre::EnumGenre genre,const QString & email,const QString & telephone,list_of_CongesEmploye list_of_CngEmp)
                      { setMatricule(matricule); setNom(nom); setPrenom(prenom); setGenre(genre); setEmail(email); setTelephone(telephone); setListCngEmp(list_of_CngEmp);}
    virtual ~ModelCongesEmploye(){};

    //setters & getters
    void setManager(const modelmanagr_ptr & manager) { m_manager = manager; }
    void setListCngEmp(const list_of_CongesEmploye & listCngEmp) { m_list_of_CongesEmploye = listCngEmp; }
    modelmanagr_ptr getManager() { return m_manager; }
    list_of_CongesEmploye getlist_of_CongesEmploye() { return m_list_of_CongesEmploye; }

protected:
    modelmanagr_ptr m_manager;
    list_of_CongesEmploye m_list_of_CongesEmploye;
    list_of_demandes m_list_of_demande;

private:

};

QX_REGISTER_HPP_ENTITY(ModelCongesEmploye,Personne,0)

typedef std::shared_ptr<ModelCongesEmploye> modelEmployeConge_ptr;
typedef qx::QxCollection<long, modelEmployeConge_ptr> liste_modelCngeEmploye_ptr;
typedef QList<ModelCongesEmploye> liste_modelCngeEmploye;
#endif // MODELCONGESEMPLOYE_H
