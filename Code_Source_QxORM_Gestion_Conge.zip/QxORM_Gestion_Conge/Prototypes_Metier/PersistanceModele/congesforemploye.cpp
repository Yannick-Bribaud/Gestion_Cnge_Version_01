#include "Precompilation/precompilation.h"
#include "congesforemploye.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(CongesForEmploye)

namespace qx {

    template<> void register_class(QxClass<CongesForEmploye> & CngForEmploye){

        CngForEmploye.setName("t_congesForEmploye");
        CngForEmploye.relationManyToOne(&CongesForEmploye::m_modelCongesEmploye,"idModelEmp");
    }

}


