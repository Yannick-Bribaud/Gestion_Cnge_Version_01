#include "Precompilation/precompilation.h"
#include "modelcongesmanager.h"
#include "Entites/manager.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(ModelCongesManager)
namespace qx {

    template <> void register_class(QxClass<ModelCongesManager> & model){

        model.setName("t_modelcongesmanager");
        model.data(&ModelCongesManager::pro_matricule,"matricule");
        model.data(&ModelCongesManager::pro_email, "email");

      model.relationOneToMany(&ModelCongesManager::m_list_of_ModelCongesEmploye, "list_of_ModelCongesEmploye", "idModelMng", 0);

   }
}
