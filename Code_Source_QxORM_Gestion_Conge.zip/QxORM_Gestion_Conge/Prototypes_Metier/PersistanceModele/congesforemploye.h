#ifndef CONGESFOREMPLOYE_H
#define CONGESFOREMPLOYE_H
#include "Entites/conges.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesemploye.h"

class ModelCongesEmploye;

class _QX_DLL_EXPORT_GESTION_CONGES CongesForEmploye : public Conges
{
    QX_REGISTER_FRIEND_CLASS(CongesForEmploye)

public:
    typedef std::shared_ptr <ModelCongesEmploye> modelCongeEmploye_ptr;
    void methodeAbstraite() override{};

    CongesForEmploye(){};
    CongesForEmploye(QDate debutConge, qint8 duree, QDate finConge,modelCongeEmploye_ptr modelEmploye): Conges(debutConge,duree,finConge),m_modelCongesEmploye(modelEmploye){};
    virtual ~CongesForEmploye(){};

    void setModelEmploye(const modelCongeEmploye_ptr & modelEmploye){ m_modelCongesEmploye = modelEmploye; }

protected:
    modelCongeEmploye_ptr m_modelCongesEmploye;

};

QX_REGISTER_HPP_ENTITY(CongesForEmploye,Conges,0)

typedef std::shared_ptr<CongesForEmploye>CongesForEmploye_ptr;
typedef qx::QxCollection<long, CongesForEmploye_ptr> list_of_CongesForEmploye_ptr;
typedef QList<CongesForEmploye> list_of_CongeForEmploye;


#endif // CONGESFOREMPLOYE_H
