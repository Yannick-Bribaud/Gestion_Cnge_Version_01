#ifndef VALIDATIONCONGES_H
#define VALIDATIONCONGES_H
#include "Entites/validation.h"
#include "Entites/demande.h"

class Validation;
class Demande;

class _QX_DLL_EXPORT_GESTION_CONGES ValidationConges : public Validation
{
    QX_REGISTER_FRIEND_CLASS(ValidationConges)

public:
        void methodeAbstraite() override{};

        ValidationConges(){};
        ValidationConges(const QDate & dateV, const QTime & heureV, const QString & verdict,long idDemand):Validation(dateV,heureV,verdict){ idDemande=idDemand;}
        ValidationConges(const QDate & dateV, const QTime & heureV, const QString & verdict):Validation(dateV,heureV,verdict){}
        ValidationConges(long id,const QDate & dateV, const QTime & heureV, const QString & verdict):Validation(id,dateV,heureV,verdict){}
        virtual ~ValidationConges(){};

        void setIdDemande(const long & id) { idDemande=id;}
        long getIdDemande() const {return idDemande;}

protected:
    long idDemande;

};

QX_REGISTER_HPP_ENTITY(ValidationConges,Validation,0)
typedef std::shared_ptr<ValidationConges> ValidationConges_ptr;
typedef qx::QxCollection<long, ValidationConges_ptr> liste_validationCnge_ptr;

#endif // VALIDATIONCONGES_H
