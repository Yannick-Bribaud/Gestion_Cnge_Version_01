#include "Precompilation/precompilation.h"
#include "modelcongesemploye.h"
#include "Entites/manager.h"
#include <QxOrm_Impl.h>

QX_REGISTER_CPP_ENTITY(ModelCongesEmploye)

namespace qx {

template <> void register_class(QxClass<ModelCongesEmploye> & Model){

        Model.setName("t_modelCongesEmploye");

        Model.data(&ModelCongesEmploye::pro_matricule,"matricule");
        Model.data(&ModelCongesEmploye::pro_email, "email");

      /*  Model.data(&ModelCongesEmploye::e_debutPeriode,"debutPeriode");
        Model.data(&ModelCongesEmploye::e_finPeriode,"finPeriode");
        Model.data(&ModelCongesEmploye::e_soldeConge, "soldeConge");
        Model.data(&ModelCongesEmploye::pro_profession,"profession");
        Model.data(&ModelCongesEmploye::pro_status, "status");
        Model.data(&ModelCongesEmploye::pro_login, "login");
        Model.data(&ModelCongesEmploye::pro_password, "password");*/

        Model.relationManyToOne(&ModelCongesEmploye::m_manager,"idModelMng");
        Model.relationOneToMany(&ModelCongesEmploye::m_list_of_CongesEmploye, "list_of_CongesEmploye","idModelEmp",0);
        Model.relationOneToMany(&ModelCongesEmploye::m_list_of_demande, "list_of_demandes","idEmploye",0);
 }
}
