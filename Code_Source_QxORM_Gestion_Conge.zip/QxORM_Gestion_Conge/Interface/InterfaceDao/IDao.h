#ifndef IDAO_H
#define IDAO_H
#include "Entites/administrateur.h"
#include "Entites/conges.h"
#include "Entites/demande.h"
#include "Entites/directeur_rh.h"
#include "Entites/employe.h"
#include "Entites/genre.h"
#include "Entites/manager.h"
#include "Entites/professionnel.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesemploye.h"
#include "Prototypes_Metier/PersistanceModele/modelcongesmanager.h"

class _QX_DLL_EXPORT_GESTION_CONGES IDao
{

public:

    virtual modelCongesManagers_ptr getMngOfModelCngEmp(modelEmployeConge_ptr modelEmploye)=0;
    virtual list_of_ModelCongesEmploye getListModelCngEmploye(modelCongesManagers_ptr manager)=0;
    virtual professionel_ptr getProfessionalInfoFromEmploye(employe_ptr employe)=0;
    virtual professionel_ptr getProfessionalInfoFromManager(Managr_ptr manager)=0;
    virtual professionel_ptr getProfessionalInfoFromAdministrator(admin_ptr admin)=0;
    virtual professionel_ptr getProfessionalInfoFromDirecteurRh(drh_ptr drh)=0;
    virtual void PersisteProfessionnelInfo(professionel_ptr professionnel)=0;
    virtual professionel_ptr checkIdentifier(QString login, QString password)=0;


};

#endif // IDAO_H
