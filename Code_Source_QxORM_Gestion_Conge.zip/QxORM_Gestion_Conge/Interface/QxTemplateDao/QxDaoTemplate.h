#ifndef QXDAOTEMPLATE_H
#define QXDAOTEMPLATE_H
#include "Entites/professionnel.h"
#include "Precompilation/precompilation.h"
#include "Exceptions/SqlExceptions/daoexception.h"

namespace QxDaoTemplate {
namespace PersisteObject{
template <typename T>
bool SaveListWithAllRltn(qx::QxCollection<long,std::shared_ptr<T>>&Object){
       QSqlError daoError= qx::dao::save_with_all_relation(Object);
       if(!daoError.isValid()) return true;
       throw daoException(daoError.text());
};

template <typename T>
bool SaveList(qx::QxCollection<long,std::shared_ptr<T>>&Object){
    QSqlError daoError=qx::dao::save(Object);
          if(!daoError.isValid()) return true;

};

template<typename T>
bool SaveListWithInsertFnct(qx::QxCollection<long,std::shared_ptr<T>>&Object){
     QSqlError daoError=qx::dao::insert(Object);
     if(!daoError.isValid()) return true;
     throw daoException(daoError.text());
};

template <typename T>
bool SaveObject(T &Object){
    QSqlError daoError=qx::dao::save(Object);
     if(!daoError.isValid()) return true;
     throw daoException(daoError.text());

};

template<typename T>
bool SaveObjectWithInsert(T & Object){
     QSqlError daoError=qx::dao::insert(Object);
     if(!daoError.isValid()) return true;
     throw daoException(daoError.text());
};
}//EndOfPersisteObjectNamespace


namespace UPdateObject {

template <typename T>
bool Update(qx::QxCollection<long,std::shared_ptr<T>>&Object){
      QSqlError daoError=qx::dao::update(Object);
      if(!daoError.isValid()) return true;
       throw daoException(daoError.text());
};

template <typename T>
bool UpdateObject(T &Object){
      QSqlError daoError=qx::dao::update(Object);
      if(!daoError.isValid()) return true;
       throw daoException(daoError.text());
};

template <typename T>
bool UpdateWithAllRelation(qx::QxCollection<long,std::shared_ptr<T>>&Object){
     QSqlError daoError=qx::dao::update(Object);
      if(!daoError.isValid()) return true;
       throw daoException(daoError.text());
};

template <typename T>
bool UpdateObjectWithAllRelation(T &Object){
     QSqlError daoError=qx::dao::update(Object);
      if(!daoError.isValid()) return true;
       throw daoException(daoError.text());
};


template <typename T>
bool UpadateOptimized(qx::QxCollection<long, std::shared_ptr<T>> &Object){
    QSqlError daoError=qx::dao::update_optimized(Object);
    if(!daoError.isValid()) return true;
    throw daoException(daoError.text());
};

template <typename T>
bool UpadateOptimizedObject(T &Object){
    QSqlError daoError=qx::dao::update_optimized(Object);
    if(!daoError.isValid()) return true;
    throw daoException(daoError.text());
};
}//EndOfUpdate


namespace DeleteObject {
template <typename T>
void DeleteById(T & Object){
     QSqlError daoError=qx::dao::delete_by_id(Object);
   if(!daoError.isValid()) return ;
     throw daoException(daoError.text());
};


template <typename T>
void DeleteAllObject(T & Object){
    QSqlError daoError=qx::dao::delete_all<T>();
    if(!daoError.isValid()) return ;
     throw daoException(daoError.text());
};

template <typename T>
void destroyById(T & Object){
     QSqlError daoError=qx::dao::destroy_by_id(Object);
     if(!daoError.isValid()) return;
     throw daoException(daoError.text());

};

template <typename T>
void destroyedAll(T & Object){
    QSqlError daoError=qx::dao::destroy_all<T>();
    if(!daoError.isValid()) return;
      throw daoException(daoError.text());
};
}//EndOfDelete


namespace getDataTable {

template <typename  T>
QList<T>SelectAllDataOfTable(T){

   QList<T>liste; liste.clear();
   QSqlError daoError = qx::dao::fetch_all(liste);
   if(!daoError.isValid()) return liste;
   throw daoException(daoError.text());
};

template <typename T>
T getObjectById(T object){
    QSqlError daoError = qx::dao::fetch_by_id(object);
    if(!daoError.isValid()) return object;
    throw daoException(daoError.text());
};
}//endOfSelect
}//EndOfNamespace

#endif // QXDAOTEMPLATE_H




