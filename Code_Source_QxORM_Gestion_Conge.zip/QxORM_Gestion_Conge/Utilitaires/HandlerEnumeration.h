#ifndef HANDLERENUMERATION_H
#define HANDLERENUMERATION_H

#include <QString>
#include <QDebug>
#include <QMetaEnum>

namespace HandlerEnums {

//outils de conversions d'une énumeration

template <typename E> E fromString(const QString &text){
    bool valide;
    auto resultat = static_cast<E>(QMetaEnum::fromType<E>().keyToValue(text.toUtf8(),&valide));
    if(!valide){
       return {};
    }
    return resultat;
}


template <typename E> QString convertToString(E value){

    const int indiceEnum = static_cast<int>(value);
    return QString::fromUtf8(QMetaEnum::fromType<E>().valueToKey(indiceEnum));
};

}

#endif // HANDLERENUMERATION_H
