#include "servicesexceptions.h"

ServicesExceptions::ServicesExceptions(const QString &  message){
    this->message=message;
}

QString ServicesExceptions::getMessage() const{
    return message;
}
