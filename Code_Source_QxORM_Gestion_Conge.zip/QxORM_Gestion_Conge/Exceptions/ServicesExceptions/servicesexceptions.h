#ifndef SERVICESEXCEPTIONS_H
#define SERVICESEXCEPTIONS_H


class ServicesExceptions : public QSqlError
{
public:
    ServicesExceptions(const QString & message);
    QString getMessage()const;
private:
    QString message;
};

#endif // SERVICESEXCEPTIONS_H
