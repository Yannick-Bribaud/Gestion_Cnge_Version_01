#ifndef DBERROR_H
#define DBERROR_H

#include <QString>
#include <QException>
#include <QSqlError>

class dbError : public QException,public QSqlError
{

public:
    dbError(QString message);
    dbError( const ErrorType & e):error(e){};
    dbError(QSqlError & e):Qerror(e){};
    QString getMessage() const;
    long getCodErreur() const { return this->error; }
    QString getSqlError()const {return Qerror.text();}



private:
    QString message;
    ErrorType error;
    QSqlError Qerror;

};

#endif // DBERROR_H
