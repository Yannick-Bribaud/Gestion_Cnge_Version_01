#include "userExceptions.h"

userExceptions::userExceptions(QString message){
     this->message=message;
}
