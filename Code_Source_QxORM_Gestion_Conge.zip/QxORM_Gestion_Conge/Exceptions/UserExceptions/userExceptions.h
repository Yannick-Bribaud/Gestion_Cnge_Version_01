#ifndef USEREXCEPTIONS_H
#define USEREXCEPTIONS_H
#include <QException>

class userExceptions : public QException
{
public:
    userExceptions(QString message);
    QString getMessage()const {return message; }

private:
    QString message;
};

#endif // USEREXCEPTIONS_H
