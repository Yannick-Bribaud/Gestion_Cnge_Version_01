#ifndef DAOEXCEPTION_H
#define DAOEXCEPTION_H


class daoException : public QSqlError
{
public:
    daoException(const QString & message): message(message){};
    daoException(ErrorType & e):typError(e){};
    daoException(ErrorType & e, QSqlError & ex):typError(e),sqlError(ex){};
    QString getMessage() const { return message; }
    long getCodErreur()const { return typError;}
    QString getSqlError() const { return sqlError.text(); }


private:
    QString message;
    ErrorType typError;
    QSqlError sqlError;

};

#endif // DAOEXCEPTION_H
