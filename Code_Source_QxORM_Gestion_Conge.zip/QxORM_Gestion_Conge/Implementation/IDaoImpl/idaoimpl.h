#ifndef IDAOIMPL_H
#define IDAOIMPL_H
#include "Interface/InterfaceDao/IDao.h"
#include "Exceptions/SqlExceptions/daoexception.h"
#include "Qx_Connect_db/qxdbconnect.h"

class _QX_DLL_EXPORT_GESTION_CONGES  IDaoImpl : public IDao
{
public:
    IDaoImpl();
    virtual ~IDaoImpl(){};

    modelCongesManagers_ptr getMngOfModelCngEmp(modelEmployeConge_ptr modelEmploye) override;
    list_of_ModelCongesEmploye getListModelCngEmploye(modelCongesManagers_ptr manager) override;
    professionel_ptr getProfessionalInfoFromAdministrator(admin_ptr admin) override;
    professionel_ptr getProfessionalInfoFromDirecteurRh(drh_ptr drh) override;
    professionel_ptr getProfessionalInfoFromEmploye(employe_ptr employe) override;
    professionel_ptr getProfessionalInfoFromManager(Managr_ptr manager) override;
    void PersisteProfessionnelInfo(professionel_ptr professionnel) override;
    professionel_ptr checkIdentifier(QString login, QString password) override;

private:
    QxdbConnect * mydb;

};

#endif // IDAOIMPL_H
