#include "Precompilation/precompilation.h"
#include "idaoimpl.h"
#include <QxOrm_Impl.h>

IDaoImpl::IDaoImpl()
{

}

modelCongesManagers_ptr IDaoImpl::getMngOfModelCngEmp(modelEmployeConge_ptr modelEmploye){
    QSqlError daoError = qx::dao::fetch_by_id_with_relation("idModelMng",modelEmploye);
    if(daoError.isValid()) throw daoException(daoError.text());
    return modelEmploye->getManager();
}

list_of_ModelCongesEmploye IDaoImpl::getListModelCngEmploye(modelCongesManagers_ptr manager){
    QSqlError daoError = qx::dao::fetch_by_id_with_relation("list_of_ModelCongesEmploye",manager);
     if(daoError.isValid()) throw daoException(daoError.text());
     return manager->getlist_of_ModelCongesEmploye();
}

professionel_ptr IDaoImpl::getProfessionalInfoFromAdministrator(admin_ptr admin){
      professionel_ptr adrObject;
      adrObject.reset(new Professionnel(admin->getNom(),admin->getPrenom(),admin->getGenreEnum(),
                                        admin->getDateNaissance(),admin->getAdresse(),admin->getTelephone(),
                                        admin->getMatricule(),admin->getProfession(),admin->getStatusEnum(),
                                        admin->getLoging(),admin->getPassword(),admin->getEmail()));
      return adrObject;
}

professionel_ptr IDaoImpl::getProfessionalInfoFromDirecteurRh(drh_ptr drh){
    professionel_ptr adrObject;
    adrObject.reset(new Professionnel(drh->getNom(),drh->getPrenom(),drh->getGenreEnum(),
                                      drh->getDateNaissance(),drh->getAdresse(),drh->getTelephone(),
                                      drh->getMatricule(),drh->getProfession(),drh->getStatusEnum(),
                                      drh->getLoging(),drh->getPassword(),drh->getEmail()));
    return adrObject;
}

professionel_ptr IDaoImpl::getProfessionalInfoFromEmploye(employe_ptr employe){
    professionel_ptr adrObject;
    adrObject.reset(new Professionnel(employe->getNom(),employe->getPrenom(),employe->getGenreEnum(),
                                      employe->getDateNaissance(),employe->getAdresse(),employe->getTelephone(),
                                      employe->getMatricule(),employe->getProfession(),employe->getStatusEnum(),
                                      employe->getLoging(),employe->getPassword(),employe->getEmail()));
    return adrObject;
}

professionel_ptr IDaoImpl::getProfessionalInfoFromManager(Managr_ptr manager)
{
    professionel_ptr adrObject;
    adrObject.reset(new Professionnel(manager->getNom(),manager->getPrenom(),manager->getGenreEnum(),
                                      manager->getDateNaissance(),manager->getAdresse(),manager->getTelephone(),
                                      manager->getMatricule(),manager->getProfession(),manager->getStatusEnum(),
                                      manager->getLoging(),manager->getPassword(),manager->getEmail()));
    return adrObject;
}

void IDaoImpl::PersisteProfessionnelInfo(professionel_ptr professionnel){

    try {
         mydb = QxdbConnect::getInstance();

         if(mydb->isConnected()){
          QSqlError daoError = qx::dao::save(professionnel);
          if(daoError.isValid()) throw daoException(daoError.text());
         }
    }catch (dbError e) {
       throw daoException(e.getMessage());
    }
}

professionel_ptr IDaoImpl::checkIdentifier(QString login, QString password){
    professionel_ptr Check; Check.reset(new Professionnel());

    try{
        mydb=QxdbConnect::getInstance();

        if(mydb->OpenDataBase()){

            qx_query query("SELECT t_professionnel.status,t_professionnel.nom,t_professionnel.prenom,t_professionnel.matricule,t_professionnel.genre FROM t_professionnel WHERE t_professionnel.login=:login AND t_professionnel.password=:password");
            query.bind(":login",login);
            query.bind(":password",password);
            QSqlError daoError = qx::dao::execute_query(query,Check);

          if(daoError.isValid()){
              throw daoException(daoError.text());
           }else{
             mydb->close();
             return Check;
         }
      }
    }catch (dbError e) {
     long error=e.getCodErreur();
       if(error==1){
         QString message="unable to open connection to database can't connect to MySQL server on localhost";
         throw daoException(message);
       }

 }
    return  nullptr;

}
